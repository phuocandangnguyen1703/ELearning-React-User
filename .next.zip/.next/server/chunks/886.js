"use strict";
exports.id = 886;
exports.ids = [886];
exports.modules = {

/***/ 4168:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _redux_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4665);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1239);
/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(events__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



class AxiosServices {
    static{
        this.isFetchingToken = false;
    }
    static{
        this.eventController = new (events__WEBPACK_IMPORTED_MODULE_2___default())();
    }
    constructor(){
        const instance = axios__WEBPACK_IMPORTED_MODULE_1__["default"].create({
            baseURL: "https://node.edupath.ftisu.vn/"
        });
        instance.interceptors.response.use(this.handleSuccess, this.handleError);
        instance.interceptors.request.use(async (config)=>{
            config.headers.Authorization = "Bearer " + _redux_store__WEBPACK_IMPORTED_MODULE_0__/* ["default"].getState */ .Z.getState().user.token;
            // config.headers!['Content-Type'] = 'application/json';
            // return config as any;
            return config;
        }, this.handleError);
        axios__WEBPACK_IMPORTED_MODULE_1__["default"].defaults.withCredentials = true;
        this.instance = instance;
    // this.instance.defaults.timeout = 20000
    }
    handleSuccess(response) {
        return response;
    }
    handleError(error) {
        return Promise.reject(error);
    }
    get(url, config) {
        return this.instance.get(url, config);
    }
    getImage(url) {
        return this.instance.get(url, {
            responseType: "blob"
        });
    }
    post(url, data, config) {
        return this.instance.post(url, data, config);
    }
    put(url, data, config) {
        return this.instance.put(url, data, config);
    }
    delete(url, config) {
        return this.instance.delete(url, config);
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AxiosServices);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7445:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ history),
/* harmony export */   "m": () => (/* binding */ getChat)
/* harmony export */ });
/* harmony import */ var apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4168);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__]);
apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getChat = (question)=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get(`chatbot/chat?question=${question}`);
};
const history = ()=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get(`chatbot/history`);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6849:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "XR": () => (/* binding */ getCourse),
/* harmony export */   "im": () => (/* binding */ allCourses),
/* harmony export */   "to": () => (/* binding */ getCoursesOfMaintype)
/* harmony export */ });
/* harmony import */ var apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4168);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__]);
apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getCourse = (courseId)=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get(`course/item/${courseId}`);
};
const getCoursesOfMaintype = (courseId)=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get(`course/courses_of_maintype?course_id=${courseId}`);
};
const allCourses = ()=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get(`course/all_courses`);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3516:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "tO": () => (/* binding */ storage)
/* harmony export */ });
/* unused harmony exports app, default */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3745);
/* harmony import */ var firebase_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3392);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_storage__WEBPACK_IMPORTED_MODULE_1__]);
([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_storage__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const firebaseConfig = {
    apiKey: "AIzaSyAZR_xXI0qJiElBvr0zE7aNq-I6IUUzcgM",
    authDomain: "edupath-dfcd4.firebaseapp.com",
    projectId: "edupath-dfcd4",
    storageBucket: "edupath-dfcd4.appspot.com",
    messagingSenderId: "667725875299",
    appId: "1:667725875299:web:6d44a990f1ba6d21279056"
};
const app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__.initializeApp)(firebaseConfig);
const storage = (0,firebase_storage__WEBPACK_IMPORTED_MODULE_1__.getStorage)(app);
const storageRef = (0,firebase_storage__WEBPACK_IMPORTED_MODULE_1__.ref)(storage);


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3600:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ getVideo)
/* harmony export */ });
/* harmony import */ var apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4168);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__]);
apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getVideo = async (lessonId, courseId)=>{
    return await new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get(`/learning/video/${lessonId}?course_id=${courseId}`, {
        responseType: "blob"
    }).then((success)=>URL.createObjectURL(success.data));
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8088:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DP": () => (/* binding */ makePayment),
/* harmony export */   "JV": () => (/* binding */ checkPayment),
/* harmony export */   "b6": () => (/* binding */ getCoursePrice),
/* harmony export */   "oB": () => (/* binding */ getCoursesSimilar)
/* harmony export */ });
/* harmony import */ var apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4168);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__]);
apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getCoursesSimilar = (courseId)=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get(`payment/courses_similar?course_id=${courseId}`);
};
const getCoursePrice = (courseId)=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get(`payment/course_price?course_id=${courseId}`);
};
const checkPayment = (courseId)=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get(`payment/check_payment?course_id=${courseId}`);
};
const makePayment = (courseId)=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get(`payment/make_payment?course_id=${courseId}`);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3359:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AT": () => (/* binding */ processRecommend),
/* harmony export */   "Bg": () => (/* binding */ chooseMaintype),
/* harmony export */   "QL": () => (/* binding */ listTag),
/* harmony export */   "XZ": () => (/* binding */ checkStatus)
/* harmony export */ });
/* harmony import */ var apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4168);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__]);
apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const checkStatus = (userId)=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get(`recommend/check_status/${userId}`);
};
const listTag = ()=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get("/recommend/list_tag");
};
const processRecommend = (skills)=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().post("/recommend/process_recommend", {
        skills
    });
};
const chooseMaintype = (choosen)=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get(`/recommend/choose_maintype?choosen=${choosen}`);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4002:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ postReview),
/* harmony export */   "v": () => (/* binding */ getCourseReview)
/* harmony export */ });
/* harmony import */ var apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4168);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__]);
apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const postReview = (data)=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().post(`review/new`, data);
};
const getCourseReview = (courseId)=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get(`review/course_review/${courseId}`);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1482:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ getCoursesSimilarTag),
/* harmony export */   "c": () => (/* binding */ myRoadmap)
/* harmony export */ });
/* harmony import */ var apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4168);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__]);
apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const myRoadmap = ()=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get(`roadmap/my_roadmap`);
};
const getCoursesSimilarTag = (detailId)=>{
    return new apis_axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().get(`roadmap/courses_similar_tag?detail_id=${detailId}`);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6607:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B": () => (/* binding */ searchCourses)
/* harmony export */ });
/* harmony import */ var _axiosServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4168);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axiosServices__WEBPACK_IMPORTED_MODULE_0__]);
_axiosServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const searchCourses = async (data)=>{
    return new _axiosServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().post(`search/courses`, data);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 632:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* reexport */ star)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./assets/detail/star.svg
var _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgStar = function SvgStar(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 68 62"
  }, props), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M67.156 22.537a3.032 3.032 0 0 0-1.11-1.404 3.558 3.558 0 0 0-1.783-.624L45.259 19.15 37.036 2.767a3.106 3.106 0 0 0-1.226-1.29A3.6 3.6 0 0 0 34 .994a3.6 3.6 0 0 0-1.81.48 3.107 3.107 0 0 0-1.227 1.29L22.739 19.15 3.736 20.509a3.56 3.56 0 0 0-1.758.605c-.51.35-.896.824-1.114 1.366a2.716 2.716 0 0 0-.113 1.691c.143.562.463 1.075.922 1.477l14.043 12.321-4.967 19.356c-.15.586-.102 1.2.14 1.76.24.56.663 1.044 1.213 1.385.55.342 1.201.527 1.87.532a3.603 3.603 0 0 0 1.877-.506L34 49.606l18.15 10.89c.568.34 1.238.514 1.92.5a3.585 3.585 0 0 0 1.892-.575c.55-.361.965-.866 1.188-1.446.222-.58.242-1.207.057-1.797l-6.097-19.2 15.12-12.246c.99-.804 1.354-2.058.927-3.195Z"
  })));
};
/* harmony default export */ const star = (SvgStar);
;// CONCATENATED MODULE: ./assets/detail/index.tsx



/***/ }),

/***/ 6799:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z8": () => (/* reexport */ bot),
  "tW": () => (/* reexport */ android),
  "y3": () => (/* reexport */ backend),
  "tb": () => (/* reexport */ blockchain),
  "qz": () => (/* reexport */ recents),
  "Hk": () => (/* reexport */ devops),
  "kD": () => (/* reexport */ flutter),
  "tQ": () => (/* reexport */ frontend)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./assets/home/bot.svg
var _path, _path2, _path3, _ellipse, _ellipse2, _path4, _path5, _path6, _ellipse3, _ellipse4, _ellipse5, _ellipse6;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgBot = function SvgBot(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 98 97"
  }, props), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    fill: "#fff",
    stroke: "#2F80ED",
    strokeWidth: 2.5,
    d: "M49.661 94.872c-10.837 0-14.217 1.674-16.395-7.087h33.07c-2.07 7.794-6.67 7.087-16.675 7.087ZM5.841 58.298c-.01-7.914-1.544-10.398 7.216-12l.032 24.149c-7.796-1.5-7.237-4.234-7.248-12.149Z"
  })), _path2 || (_path2 = /*#__PURE__*/external_react_.createElement("path", {
    fill: "#fff",
    stroke: "#2F80ED",
    strokeWidth: 2.5,
    d: "M2.063 58.34c-.007-4.655-.806-6.117 3.76-7.059l.019 14.207c-4.064-.883-3.773-2.491-3.78-7.147ZM92.825 58.298c.01-7.914 1.544-10.398-7.216-12l-.032 24.149c7.796-1.5 7.237-4.234 7.248-12.149Z"
  })), _path3 || (_path3 = /*#__PURE__*/external_react_.createElement("path", {
    fill: "#fff",
    stroke: "#2F80ED",
    strokeWidth: 2.5,
    d: "M96.603 58.34c.007-4.655.806-6.117-3.76-7.059l-.019 14.207c4.064-.883 3.773-2.491 3.78-7.147ZM38.027 18.64c0 5.022-.856 9.51-2.192 12.696-.669 1.595-1.434 2.805-2.22 3.598-.78.787-1.507 1.095-2.154 1.095s-1.374-.308-2.155-1.095c-.785-.793-1.55-2.003-2.22-3.598-1.335-3.186-2.191-7.674-2.191-12.697 0-5.022.856-9.51 2.192-12.696.669-1.596 1.434-2.806 2.22-3.598.78-.788 1.507-1.095 2.154-1.095s1.374.307 2.155 1.095c.785.792 1.55 2.002 2.22 3.598 1.335 3.186 2.191 7.674 2.191 12.696ZM74.705 18.64c0 5.022-.856 9.51-2.192 12.696-.67 1.595-1.434 2.805-2.22 3.598-.78.787-1.508 1.095-2.154 1.095-.647 0-1.374-.308-2.155-1.095-.786-.793-1.55-2.003-2.22-3.598-1.336-3.186-2.192-7.674-2.192-12.697 0-5.022.856-9.51 2.192-12.696.67-1.596 1.434-2.806 2.22-3.598.78-.788 1.508-1.095 2.155-1.095.646 0 1.374.307 2.155 1.095.785.792 1.55 2.002 2.219 3.598 1.336 3.186 2.192 7.674 2.192 12.696Z"
  })), _ellipse || (_ellipse = /*#__PURE__*/external_react_.createElement("ellipse", {
    cx: 32.063,
    cy: 21.345,
    fill: "#2F80ED",
    rx: 3.006,
    ry: 8.117
  })), _ellipse2 || (_ellipse2 = /*#__PURE__*/external_react_.createElement("ellipse", {
    cx: 68.139,
    cy: 21.345,
    fill: "#2F80ED",
    rx: 3.006,
    ry: 8.117
  })), _path4 || (_path4 = /*#__PURE__*/external_react_.createElement("path", {
    fill: "#fff",
    stroke: "#2F80ED",
    strokeWidth: 2.5,
    d: "M88.535 56.218c0 18.59-17.187 33.924-38.734 33.924-21.548 0-38.735-15.334-38.735-33.924s17.187-33.924 38.735-33.924c21.547 0 38.734 15.334 38.734 33.924Z"
  })), _path5 || (_path5 = /*#__PURE__*/external_react_.createElement("path", {
    fill: "#2F80ED",
    fillOpacity: 0.5,
    d: "M78.962 56.82c0 12.12-10.222 26.756-29.162 26.756-20.744 0-29.161-14.636-29.161-26.756 0-12.121 13.388-17.136 29.161-17.136 15.773 0 29.162 5.015 29.162 17.136Z"
  })), _path6 || (_path6 = /*#__PURE__*/external_react_.createElement("path", {
    fill: "#24245D",
    fillOpacity: 0.8,
    d: "M54.911 74.133c0 1.826-1.791 4.032-5.11 4.032-3.636 0-5.111-2.206-5.111-4.032 0-1.827 2.346-1.981 5.11-1.981 2.765 0 5.111.154 5.111 1.98Z"
  })), _ellipse3 || (_ellipse3 = /*#__PURE__*/external_react_.createElement("ellipse", {
    cx: 38.977,
    cy: 58.022,
    fill: "#24245D",
    rx: 7.516,
    ry: 9.32
  })), _ellipse4 || (_ellipse4 = /*#__PURE__*/external_react_.createElement("ellipse", {
    cx: 40.179,
    cy: 56.519,
    fill: "#fff",
    rx: 5.111,
    ry: 6.614
  })), _ellipse5 || (_ellipse5 = /*#__PURE__*/external_react_.createElement("ellipse", {
    cx: 60.623,
    cy: 58.022,
    fill: "#24245D",
    rx: 7.516,
    ry: 9.32
  })), _ellipse6 || (_ellipse6 = /*#__PURE__*/external_react_.createElement("ellipse", {
    cx: 61.826,
    cy: 56.519,
    fill: "#fff",
    rx: 5.111,
    ry: 6.614
  })));
};
/* harmony default export */ const bot = (SvgBot);
;// CONCATENATED MODULE: ./assets/home/recents.jpg
/* harmony default export */ const recents = ({"src":"/_next/static/media/recents.c3ace65d.jpg","height":3328,"width":1140,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgAAwMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAkgsH/8QAHBAAAAYDAAAAAAAAAAAAAAAAAAECBREUITJR/9oACAEBAAE/AK7UemU9kf/EABURAQEAAAAAAAAAAAAAAAAAAAAR/9oACAECAQE/AK//xAAYEQACAwAAAAAAAAAAAAAAAAAAARJhkf/aAAgBAwEBPwCNvT//2Q==","blurWidth":3,"blurHeight":8});
;// CONCATENATED MODULE: ./assets/home/frontend.jpg
/* harmony default export */ const frontend = ({"src":"/_next/static/media/frontend.3d71b83b.jpg","height":360,"width":684,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAABAX/2gAMAwEAAhADEAAAAJIWzf/EABsQAAICAwEAAAAAAAAAAAAAAAECAxIABRFh/9oACAEBAAE/ANbBEytZLGxHT5n/xAAYEQACAwAAAAAAAAAAAAAAAAABAgAxQf/aAAgBAgEBPwBFUihk/8QAGREAAQUAAAAAAAAAAAAAAAAAAQACEiFB/9oACAEDAQE/ACTJ16v/2Q==","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./assets/home/backend.jpg
/* harmony default export */ const backend = ({"src":"/_next/static/media/backend.f7a5ea1d.jpg","height":286,"width":533,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAwX/2gAMAwEAAhADEAAAAIQWE//EABwQAAICAgMAAAAAAAAAAAAAAAEDESEAEgIUcf/aAAgBAQABPwBbWr7ChzOhZYN3tE+5/8QAGREAAQUAAAAAAAAAAAAAAAAAAQADISJB/9oACAECAQE/AHAKxi//xAAXEQEAAwAAAAAAAAAAAAAAAAABAAMh/9oACAEDAQE/ALMSf//Z","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./assets/home/devops.jpg
/* harmony default export */ const devops = ({"src":"/_next/static/media/devops.86e2fc52.jpg","height":283,"width":533,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAgX/2gAMAwEAAhADEAAAAIkW3//EABsQAAEEAwAAAAAAAAAAAAAAABEAAQISBBMi/9oACAEBAAE/AHicYFzulCx6Fl//xAAZEQABBQAAAAAAAAAAAAAAAAABAAMycbH/2gAIAQIBAT8AeMKOlf/EABgRAAIDAAAAAAAAAAAAAAAAAAEhAAJC/9oACAEDAQE/ALAJZE//2Q==","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./assets/home/blockchain.jpg
/* harmony default export */ const blockchain = ({"src":"/_next/static/media/blockchain.1e53023f.jpg","height":286,"width":352,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAAAwX/2gAMAwEAAhADEAAAAIQqB//EABwQAAICAgMAAAAAAAAAAAAAAAECAxIABBExQf/aAAgBAQABPwCKPVdYwiG4dg5sbBrdc+5//8QAGBEAAgMAAAAAAAAAAAAAAAAAAREAAyL/2gAIAQIBAT8AsKWRP//EABcRAAMBAAAAAAAAAAAAAAAAAAABEcH/2gAIAQMBAT8AWU//2Q==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./assets/home/flutter.jpg
/* harmony default export */ const flutter = ({"src":"/_next/static/media/flutter.e61e6ef7.jpg","height":286,"width":352,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAABAX/2gAMAwEAAhADEAAAAIgsF//EAB0QAAIBBAMAAAAAAAAAAAAAAAEEAwACERJBUnP/2gAIAQEAAT8AUXSiWMbBkLmwIt9D2HOa/8QAGREBAAIDAAAAAAAAAAAAAAAAAgABESEi/9oACAECAQE/ALeCODup/8QAFxEAAwEAAAAAAAAAAAAAAAAAAAECIf/aAAgBAwEBPwDXVH//2Q==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./assets/home/android.jpg
/* harmony default export */ const android = ({"src":"/_next/static/media/android.610fc197.jpg","height":286,"width":352,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAABAX/2gAMAwEAAhADEAAAAJkVDf/EABsQAAIDAAMAAAAAAAAAAAAAAAEDAhESAFFx/9oACAEBAAE/AFzUyIUVU0TrQNS3rv3n/8QAGBEAAgMAAAAAAAAAAAAAAAAAAAIBIjL/2gAIAQIBAT8Ads1g/8QAFhEBAQEAAAAAAAAAAAAAAAAAAQAR/9oACAEDAQE/AA1b/9k=","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./assets/home/index.tsx










/***/ }),

/***/ 2899:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Q": () => (/* reexport */ thumbnail)
});

;// CONCATENATED MODULE: ./assets/learning/thumbnail.png
/* harmony default export */ const thumbnail = ({"src":"/_next/static/media/thumbnail.3b5acf98.png","height":2880,"width":5120,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAhUlEQVR42mOIiI539/Zn4FQ0NfTxcvCytnUwUde30dRjiIqJz8ktyC8qLS6tLspILcxPislNdg/3ZUjLyO7q7p08dfr8BYvSs7ILwsOb8gu8woIZvP2CUtKzYhNSEpLSXby8k7wCC4Pjg/1DGQxMrK3tXZV1zeSVjKJ9g4Ld3SxVtEzVFQD9tCfffxiiSwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./assets/learning/index.tsx



/***/ }),

/***/ 9874:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "r": () => (/* reexport */ avatar),
  "O": () => (/* reexport */ background)
});

;// CONCATENATED MODULE: ./assets/mycourse/avatar.png
/* harmony default export */ const avatar = ({"src":"/_next/static/media/avatar.cb8cc457.png","height":1379,"width":1378,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAS1BMVEXZ3OGjqK7p7PHZ3OFweYDY2+DX2+Bsdn3Y2+DLztPY2+DP09jP0thye4Hc3+Tc3uPZ3OHV2d7EyM2lqrCeo6mUmqB2foVfanFUYGley9zsAAAADnRSTlMAACcnKL+/wezs+fn5+pLCe4sAAABASURBVHjaBUCHEcAgCPyIWEgU7O4/aQ4gFmECKJmqJQKbzCnGkNrv7VUg1tZqJgj6jvFpgMv7nJ0dHh9Lif75AWUoAuzdOrIPAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assets/mycourse/background.png
/* harmony default export */ const background = ({"src":"/_next/static/media/background.f681846f.png","height":1355,"width":5310,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAIAAADq9gq6AAAAOklEQVR42mNwMjZKTUyqraktKipOSkoxNzCKDAxrbmxjyIwOKs7LSoyLC/T3j4yMtLOzd3V1aWvrAAC1qRF9lUutAgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./assets/mycourse/index.tsx




/***/ }),

/***/ 6918:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "D": () => (/* reexport */ course),
  "m": () => (/* reexport */ payment)
});

;// CONCATENATED MODULE: ./assets/payment/payment.jpg
/* harmony default export */ const payment = ({"src":"/_next/static/media/payment.7ac6c249.jpg","height":1940,"width":2132,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArwP/xAAbEAABBAMAAAAAAAAAAAAAAAASAAECERNBcf/aAAgBAQABPwCnzmUqER11f//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./assets/payment/course.jpg
/* harmony default export */ const course = ({"src":"/_next/static/media/course.75b5b7d0.jpg","height":444,"width":664,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABQEBAAAAAAAAAAAAAAAAAAAAAf/aAAwDAQACEAMQAAAArgf/xAAcEAEAAgEFAAAAAAAAAAAAAAABAgMEAAUREjH/2gAIAQEAAT8As3zPg4otbKyzpYkeB9Nf/8QAGREBAAIDAAAAAAAAAAAAAAAAAQACAxFR/9oACAECAQE/AMwVTXJ//8QAFxEAAwEAAAAAAAAAAAAAAAAAAAECIf/aAAgBAwEBPwCNR//Z","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./assets/payment/index.tsx




/***/ }),

/***/ 8930:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Hw": () => (/* binding */ ChatbotContext),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "eq": () => (/* binding */ chatbotListener)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _apis_chatbot_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7445);
/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1239);
/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(events__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(519);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_apis_chatbot_index__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _atoms__WEBPACK_IMPORTED_MODULE_5__]);
([_apis_chatbot_index__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _atoms__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const chatbotListener = new (events__WEBPACK_IMPORTED_MODULE_2___default())();
const ChatbotContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_3__.createContext)({});
const ChatbotContextProvider = (props)=>{
    const chatForm = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        defaultValues: {
            recents: [],
            list: [],
            isBegin: true
        }
    });
    const chatRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(null);
    const listForm = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useFieldArray)({
        control: chatForm.control,
        name: "list"
    });
    const value = {
        chatForm,
        listForm,
        chatRef
    };
    const loading = (0,_atoms__WEBPACK_IMPORTED_MODULE_5__/* .useLoading */ .r$)();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        (async ()=>{
            loading.open();
            await (0,_apis_chatbot_index__WEBPACK_IMPORTED_MODULE_1__/* .history */ ._)().then((success)=>chatForm.setValue("list", success.data)).catch((error)=>console.log(error));
            loading.close();
        })();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ChatbotContext.Provider, {
        value: value,
        children: props.children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChatbotContextProvider);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8831:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _apis_course__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6849);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(519);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6267);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6915);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_apis_course__WEBPACK_IMPORTED_MODULE_1__, _atoms__WEBPACK_IMPORTED_MODULE_3__]);
([_apis_course__WEBPACK_IMPORTED_MODULE_1__, _atoms__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const ActiveCourse = ({ courseId  })=>{
    const [course, setCourse] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(undefined);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (!courseId) return;
        (0,_apis_course__WEBPACK_IMPORTED_MODULE_1__/* .getCourse */ .XR)(courseId).then((success)=>setCourse(success.data)).catch((error)=>console.log(error));
    }, [
        courseId
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex-[2] h-full overflow-auto ",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "h-[45%] w-full",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_3__/* .ImageOptimizing */ .UP, {
                    blurhash: "NVKKc$Ny4n%LNG%M~qxux]o2o2X8-;kW%LoeRjt7",
                    src: `${"https://node.edupath.ftisu.vn/"}${course?.course_img}`
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "p-4",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex flex-wrap gap-2",
                                children: course?.tag_name && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .zx, {
                                    className: "!bg-[#ECF0FF] !text-[#0066FF]",
                                    children: course?.tag_name
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-1 items-center",
                                children: [
                                    [
                                        1,
                                        2,
                                        3,
                                        4,
                                        5
                                    ].map((star)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__.AiFillStar, {
                                            color: course?.star || 0 >= star ? "orange" : "gray"
                                        }, star);
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "text-[#909599] font-light text-xs",
                                        children: [
                                            "(",
                                            course?.enrollment,
                                            ")"
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-3 flex-col mt-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "uppercase text-xl",
                                children: course?.course_name
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-[#828282]",
                                children: course?.description
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-1 items-center ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_5__.BsPeople, {
                                        size: 18
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        children: [
                                            course?.enrollment,
                                            " học vi\xean đ\xe3 ghi danh"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-1 items-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__.AiOutlineClockCircle, {
                                        size: 18
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: (0,_utils_index__WEBPACK_IMPORTED_MODULE_7__/* .converDateTime */ .b)(course?.createdAt?.toString())
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-2 items-center",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: "text-xl text-[#FF852D]",
                                        children: [
                                            course?.course_fee.toLocaleString("en"),
                                            " ₫"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-base line-through",
                                        children: "6,590,000 ₫"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                href: `/course/${courseId}`,
                                className: " btn  cursor-pointerflex items-center justify-center !bg-[#0066FF]",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center not-italic text-base gap-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_5__.BsCart3, {
                                            size: 18
                                        }),
                                        "ĐĂNG K\xdd NGAY"
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ActiveCourse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 788:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_home__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6799);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9030);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _types_chatbot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5171);
/* harmony import */ var _contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8930);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_5__]);
_contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const ChatbotList = ({ chats  })=>{
    const { chatRef  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_5__/* .ChatbotContext */ .Hw);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (chatRef?.current) {
            const chatContainer = chatRef.current;
            const lastChild = chatContainer.lastElementChild;
            if (lastChild) {
                lastChild.scrollIntoView({
                    behavior: "smooth",
                    block: "end",
                    inline: "nearest"
                });
            }
        }
    }, [
        chats
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex w-full gap-3 flex-col",
        children: chats.map((chat, index)=>{
            if (chat.from === _types_chatbot__WEBPACK_IMPORTED_MODULE_4__/* .EChatbotFrom.STUDENT */ .P.STUDENT) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full flex justify-end gap-2 ",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "max-w-[70%] flex gap-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: " bg-blue-secondary rounded-s-xl rounded-br-xl py-2 px-4 text-white",
                            children: chat.messages
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: "https://cafebiz.cafebizcdn.vn/thumb_w/600/162123310254002176/2021/4/22/photo1619081646120-16190816462552046046483.jpg",
                            alt: "avatar",
                            className: "rounded-full w-9 h-9 object-cover",
                            width: 40,
                            height: 40
                        })
                    ]
                })
            }, chat._id);
            if (chat.from === _types_chatbot__WEBPACK_IMPORTED_MODULE_4__/* .EChatbotFrom.BOT */ .P.BOT) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full flex justify-start gap-2 ",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "max-w-[80%] flex gap-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-9 h-9 flex justify-center items-center rounded-full border-[1px] border-blue-secondary bg-opacity-50 p-1 object-cover shrink-0",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_home__WEBPACK_IMPORTED_MODULE_1__/* .BotIcon */ .Z8, {
                                className: "w-full h-full"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: " bg-gray-200 rounded-e-xl rounded-bl-xl py-2 px-4 text-black",
                            children: chat.messages
                        })
                    ]
                })
            }, chat._id);
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChatbotList);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3475:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ChatbotRecentItem = (props)=>{
    return /*#__PURE__*/ _jsxs("div", {
        className: " bg-white flex flex-col gap-[1px] text-gray-secondary rounded-2xl px-[12px] py-[6px] cursor-pointer",
        children: [
            /*#__PURE__*/ _jsx("span", {
                className: " font-light text-sm",
                children: "• 2mins ago"
            }),
            /*#__PURE__*/ _jsx("span", {
                className: " font-semibold text-sm text-ellipsis overflow-hidden whitespace-nowrap",
                children: "Designing SaaS UI as a developer"
            }),
            /*#__PURE__*/ _jsx("span", {
                className: " font-light text-sm",
                children: "5 questions asked"
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ChatbotRecentItem)));


/***/ }),

/***/ 9595:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(519);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8930);
/* harmony import */ var apis_chatbot__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7445);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6555);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _types_chatbot__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5171);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_atoms__WEBPACK_IMPORTED_MODULE_2__, _contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_5__, apis_chatbot__WEBPACK_IMPORTED_MODULE_6__, uuid__WEBPACK_IMPORTED_MODULE_7__]);
([_atoms__WEBPACK_IMPORTED_MODULE_2__, _contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_5__, apis_chatbot__WEBPACK_IMPORTED_MODULE_6__, uuid__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const ChatbotTyping = (props)=>{
    const [text, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const userId = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.user.id);
    const { mode ="default"  } = props;
    const { listForm  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_5__/* .ChatbotContext */ .Hw);
    const textAreaRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const handleChat = async (input)=>{
        if (!text && !input) return;
        setText("");
        listForm?.append({
            _id: (0,uuid__WEBPACK_IMPORTED_MODULE_7__.v4)(),
            user_id: userId,
            from: _types_chatbot__WEBPACK_IMPORTED_MODULE_9__/* .EChatbotFrom.STUDENT */ .P.STUDENT,
            messages: input || text,
            createdAt: new Date()
        });
        await (0,apis_chatbot__WEBPACK_IMPORTED_MODULE_6__/* .getChat */ .m)(input || text).then((success)=>{
            listForm?.append(success.data);
        }).catch((error)=>console.log(error));
    };
    const handleKeyDown = async (e)=>{
        if (e.key === "Enter") {
            e.preventDefault();
            await handleChat();
            props.onKeyDown?.(e);
            // Move cursor to the beginning of the text
            if (textAreaRef.current) {
                textAreaRef.current.selectionStart = 0;
                textAreaRef.current.selectionEnd = 0;
            }
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        _contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_5__/* .chatbotListener.on */ .eq.on("suggest", (recive)=>{
            if (!recive) return;
            handleChat(recive);
        });
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_4___default()("flex w-full items-center relative", props.className),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .TextAreaField */ .N7, {
                onKeyDown: handleKeyDown,
                name: "chat-input",
                value: props.value || text,
                onChange: (e)=>props.onChange?.(e) || setText(e.target.value),
                containerClassName: "!w-full h-10",
                noLable: true,
                inputClassName: "resize-none !w-full border-[2px] rounded-xl !px-3 flex items-center h-full !pt-[5px]",
                ref: textAreaRef
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: clsx__WEBPACK_IMPORTED_MODULE_4___default()("absolute right-0 w-12 bg-transparent p-[10px] hover:border-none hover:outline-none", props.buttonClassName),
                onClick: async (e)=>{
                    if (mode === "default") {
                        props.onSubmit?.(e);
                        return;
                    }
                    if (mode === "chatbot") {
                        await handleChat();
                        props.onSubmit?.(e);
                        return;
                    }
                },
                children: props.buttonIcon || /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_3__.IoMdSend, {
                    className: "  text-blue-secondary text-2xl mr-4 "
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChatbotTyping);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7926:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(519);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var apis_course__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6849);
/* harmony import */ var _utils_string__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2239);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6915);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_atoms__WEBPACK_IMPORTED_MODULE_2__, apis_course__WEBPACK_IMPORTED_MODULE_6__]);
([_atoms__WEBPACK_IMPORTED_MODULE_2__, apis_course__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const Course = ({ fitWidth , courseId  })=>{
    const [course, setCourse] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(undefined);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!courseId) return;
        (0,apis_course__WEBPACK_IMPORTED_MODULE_6__/* .getCourse */ .XR)(courseId).then((success)=>setCourse(success.data)).catch((error)=>console.log(error));
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_5___default()("h-[360px] bg-white w-[260px] rounded-lg p-4 flex flex-col gap-1 shadow-xl", {
            "min-w-[260px]": fitWidth
        }),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "h-[140px] rounded-lg overflow-hidden",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .ImageOptimizing */ .UP, {
                    blurhash: "NVKKc$Ny4n%LNG%M~qxux]o2o2X8-;kW%LoeRjt7",
                    src: `${"https://node.edupath.ftisu.vn/"}${course?.course_img}`
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center justify-between py-2 max-w-full overflow-hidden",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "whitespace-nowrap overflow-hidden flex justify-center items-center gap-1 opacity-75",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_3__.BiCategory, {
                                color: "gray"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-xs truncate",
                                children: course?.course_name
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "whitespace-nowrap shrink-0 flex justify-center items-center gap-1 opacity-75",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiClock, {
                                color: "gray"
                            }),
                            course?.duration && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-xs",
                                children: [
                                    Math.round(course?.duration / 24),
                                    " days"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                href: `/course/${courseId}`,
                className: "text-base font-semibold text-black",
                children: course?.course_name
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "line-clamp-3 text-sm opacity-70 flex-1",
                children: course?.description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-shrink-0",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    className: "h-10 w-10 rounded-full",
                                    src: "/avatar.png",
                                    alt: "Avatar"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "ml-4",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "text-base font-bold text-gray-900",
                                    children: course?.fullname && (0,_utils_string__WEBPACK_IMPORTED_MODULE_8__/* .extractLastName */ .a)(course?.fullname)
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex gap-1 items-center",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            className: "text-lg text-[#2F80ED] font-bold",
                            children: [
                                course?.course_fee.toLocaleString(),
                                " đ"
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Course);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8028:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(519);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_atoms__WEBPACK_IMPORTED_MODULE_2__]);
_atoms__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const MapItem = ({ details , section_name , numStep , odd =false , onTap  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("relative w-fit flex items-center col-span-2 -mt-[150px]", {
            "justify-self-end": odd,
            "justify-self-start": !odd
        }),
        children: [
            odd && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "h-fit relative",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "absolute flex items-center justify-center w-[65%] -top-3 text-4xl font-bold bg-clip-text bg-[linear-gradient(90deg,_#3B8CD2_0%,_#50B2C6_100%)] z-30 right-0 text-transparent",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "text-center w-full",
                                    children: [
                                        " ",
                                        numStep
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                className: "h-[150px] -translate-y-8",
                                viewBox: "0 0 351 197",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("line", {
                                        x1: "10.3348",
                                        y1: "190.343",
                                        x2: "189.596",
                                        y2: "101.655",
                                        stroke: "#CFCFCF",
                                        strokeWidth: 3
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ellipse", {
                                        cx: 7,
                                        cy: 192,
                                        rx: 7,
                                        ry: 5,
                                        fill: "#CFCFCF"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                                        filter: "url(#filter0_d_568_3105)",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                d: "M138 77.0936V54C138 51.2386 140.239 49 143 49H329C331.761 49 334 51.2386 334 54V79.1262C334 81.0194 332.931 82.7503 331.238 83.5976L238.786 129.863C237.358 130.577 235.674 130.567 234.255 129.834L140.706 81.5364C139.044 80.6783 138 78.9642 138 77.0936Z",
                                                fill: "url(#paint0_linear_568_3105)"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                d: "M138 77.0936V54C138 51.2386 140.239 49 143 49H329C331.761 49 334 51.2386 334 54V79.1262C334 81.0194 332.931 82.7503 331.238 83.5976L238.786 129.863C237.358 130.577 235.674 130.567 234.255 129.834L140.706 81.5364C139.044 80.6783 138 78.9642 138 77.0936Z",
                                                stroke: "url(#paint1_linear_568_3105)",
                                                strokeWidth: "2.6"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M143.509 47.7119L234.051 1.86888C236.366 0.696699 239.106 0.720236 241.401 1.93202L328.212 47.7768C333.974 50.8196 333.876 59.1058 328.043 62.0115L241.236 105.259C239.031 106.358 236.443 106.379 234.22 105.318L143.675 62.0679C137.683 59.2058 137.585 50.7114 143.509 47.7119Z",
                                        fill: "white",
                                        stroke: "url(#paint2_linear_568_3105)",
                                        strokeWidth: 2
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("defs", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("filter", {
                                                id: "filter0_d_568_3105",
                                                x: "121.7",
                                                y: "37.7002",
                                                width: "228.6",
                                                height: "113.991",
                                                filterUnits: "userSpaceOnUse",
                                                colorInterpolationFilters: "sRGB",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feFlood", {
                                                        floodOpacity: 0,
                                                        result: "BackgroundImageFix"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feColorMatrix", {
                                                        in: "SourceAlpha",
                                                        type: "matrix",
                                                        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                                                        result: "hardAlpha"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feOffset", {
                                                        dy: 5
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feGaussianBlur", {
                                                        stdDeviation: "7.5"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feComposite", {
                                                        in2: "hardAlpha",
                                                        operator: "out"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feColorMatrix", {
                                                        type: "matrix",
                                                        values: "0 0 0 0 0.427451 0 0 0 0 0.737255 0 0 0 0 0.815686 0 0 0 0.8 0"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feBlend", {
                                                        mode: "normal",
                                                        in2: "BackgroundImageFix",
                                                        result: "effect1_dropShadow_568_3105"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feBlend", {
                                                        mode: "normal",
                                                        in: "SourceGraphic",
                                                        in2: "effect1_dropShadow_568_3105",
                                                        result: "shape"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                                                id: "paint0_linear_568_3105",
                                                x1: "138.733",
                                                y1: "69.8761",
                                                x2: "334.44",
                                                y2: "71.7187",
                                                gradientUnits: "userSpaceOnUse",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                                        stopColor: "#3B8CD2"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                                        offset: 1,
                                                        stopColor: "#50B3C6"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                                                id: "paint1_linear_568_3105",
                                                x1: "138.733",
                                                y1: "48.1951",
                                                x2: "334.44",
                                                y2: "48.1951",
                                                gradientUnits: "userSpaceOnUse",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                                        stopColor: "#3B8CD2"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                                        offset: 1,
                                                        stopColor: "#50B3C6"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                                                id: "paint2_linear_568_3105",
                                                x1: "139.847",
                                                y1: "53.9853",
                                                x2: "331.478",
                                                y2: "53.9853",
                                                gradientUnits: "userSpaceOnUse",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                                        stopColor: "#3B8CD2"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                                        offset: 1,
                                                        stopColor: "#50B3C6"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-[20vw] mt-12 ml-20",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "bg-[linear-gradient(90deg,_#3B8CD2_0%,_#50B2C6_100%)] text-center text-white whitespace-nowrap text-[1.4vw] h-12 flex items-center justify-center font-bold rounded-lg",
                                children: section_name
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-[140px] overflow-y-auto grid grid-cols-2 my-4 pt-4 px-4 gap-3",
                                children: details?.map((detail)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .TagSkill */ ["if"], {
                                        isImportant: detail.is_important,
                                        onClick: ()=>onTap(detail.detail_id),
                                        isCompleted: detail.is_completed,
                                        children: detail.detail_name
                                    }, detail.detail_id))
                            })
                        ]
                    })
                ]
            }),
            !odd && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-[20vw] mt-[40px] mr-20",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "bg-[linear-gradient(90deg,_#5F5796_0%,_#3B8AD0_100%,_#FFFFFF00_100%)] text-center text-white whitespace-nowrap text-[1.4vw] h-12 flex items-center justify-center font-bold rounded-lg",
                                children: section_name
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-[140px] overflow-y-auto grid grid-cols-2 my-4 pt-4 px-4 gap-3",
                                children: details?.map((detail)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .TagSkill */ ["if"], {
                                        isImportant: detail.is_important,
                                        isCompleted: detail.is_completed,
                                        onClick: ()=>onTap(detail.detail_id),
                                        children: detail.detail_name
                                    }, detail.detail_id))
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "h-fit relative",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "absolute flex items-center justify-center w-[65%] -top-3 text-4xl font-bold bg-clip-text bg-[linear-gradient(90deg,_#5F5796_0%,_#3B8AD0_100%,_#FFFFFF00_100%)] z-30 left-0 text-transparent",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "w-full text-center",
                                    children: numStep
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                className: "h-[150px] -translate-y-8",
                                viewBox: "0 0 346 200",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("line", {
                                        y1: "-1.5",
                                        x2: "200",
                                        y2: "-1.5",
                                        transform: "matrix(-0.896306 -0.443436 -0.443436 0.896306 339.261 195.687)",
                                        stroke: "#CFCFCF",
                                        "stroke-width": "3"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ellipse", {
                                        cx: "339",
                                        cy: "195",
                                        rx: "7",
                                        ry: "5",
                                        fill: "#CFCFCF"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                                        filter: "url(#filter0_d_568_3103)",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                d: "M17 77.0936V54C17 51.2386 19.2386 49 22 49H208C210.761 49 213 51.2386 213 54V79.1262C213 81.0194 211.931 82.7503 210.238 83.5976L117.786 129.863C116.358 130.577 114.674 130.567 113.255 129.834L19.7062 81.5364C18.0441 80.6783 17 78.9642 17 77.0936Z",
                                                fill: "url(#paint0_linear_568_3103)"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                d: "M17 77.0936V54C17 51.2386 19.2386 49 22 49H208C210.761 49 213 51.2386 213 54V79.1262C213 81.0194 211.931 82.7503 210.238 83.5976L117.786 129.863C116.358 130.577 114.674 130.567 113.255 129.834L19.7062 81.5364C18.0441 80.6783 17 78.9642 17 77.0936Z",
                                                stroke: "url(#paint1_linear_568_3103)",
                                                "stroke-width": "2.6"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M22.5094 47.7119L113.051 1.86888C115.366 0.696699 118.106 0.720236 120.401 1.93202L207.212 47.7768C212.974 50.8196 212.876 59.1058 207.043 62.0115L120.236 105.259C118.031 106.358 115.443 106.379 113.22 105.318L22.675 62.0679C16.6831 59.2058 16.5851 50.7114 22.5094 47.7119Z",
                                        fill: "white",
                                        stroke: "url(#paint2_linear_568_3103)",
                                        "stroke-width": "2"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("defs", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("filter", {
                                                id: "filter0_d_568_3103",
                                                x: "0.699951",
                                                y: "37.7",
                                                width: "228.6",
                                                height: "113.991",
                                                filterUnits: "userSpaceOnUse",
                                                "color-interpolation-filters": "sRGB",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feFlood", {
                                                        "flood-opacity": "0",
                                                        result: "BackgroundImageFix"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feColorMatrix", {
                                                        in: "SourceAlpha",
                                                        type: "matrix",
                                                        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                                                        result: "hardAlpha"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feOffset", {
                                                        dy: "5"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feGaussianBlur", {
                                                        stdDeviation: "7.5"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feComposite", {
                                                        in2: "hardAlpha",
                                                        operator: "out"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feColorMatrix", {
                                                        type: "matrix",
                                                        values: "0 0 0 0 0.415686 0 0 0 0 0.639216 0 0 0 0 0.847059 0 0 0 0.8 0"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feBlend", {
                                                        mode: "normal",
                                                        in2: "BackgroundImageFix",
                                                        result: "effect1_dropShadow_568_3103"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feBlend", {
                                                        mode: "normal",
                                                        in: "SourceGraphic",
                                                        in2: "effect1_dropShadow_568_3103",
                                                        result: "shape"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                                                id: "paint0_linear_568_3103",
                                                x1: "17.7331",
                                                y1: "69.8761",
                                                x2: "213.44",
                                                y2: "71.7187",
                                                gradientUnits: "userSpaceOnUse",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                                        "stop-color": "#5F5796"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                                        offset: "1",
                                                        "stop-color": "#3B8BD1"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                                                id: "paint1_linear_568_3103",
                                                x1: "17.7331",
                                                y1: "48.1951",
                                                x2: "213.44",
                                                y2: "48.1951",
                                                gradientUnits: "userSpaceOnUse",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                                        "stop-color": "#5F5796"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                                        offset: "1",
                                                        "stop-color": "#3B8BD1"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                                                id: "paint2_linear_568_3103",
                                                x1: "18.847",
                                                y1: "53.9853",
                                                x2: "210.478",
                                                y2: "53.9853",
                                                gradientUnits: "userSpaceOnUse",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                                        "stop-color": "#5F5796"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                                        offset: "1",
                                                        "stop-color": "#3B8BD1"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MapItem);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 510:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(519);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6915);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_atoms__WEBPACK_IMPORTED_MODULE_2__]);
_atoms__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const MyCourse = (props)=>{
    const { course  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: " flex flex-col px-5 py-7 rounded-2xl bg-white gap-4 shadow-xl items-center",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .ImageOptimizing */ .UP, {
                containerClassName: "h-[10rem] w-[16rem]",
                className: " rounded-xl !w-[17rem] !h-[11rem] overflow-hidden",
                blurhash: "NVKKc$Ny4n%LNG%M~qxux]o2o2X8-;kW%LoeRjt7",
                src: `${"https://node.edupath.ftisu.vn/"}public/course/${course._id}/course_img.jpeg`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: "text-2xl text-black font-normal h-[6rem] truncate",
                children: course.course_name
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                href: `/course/${course._id}`,
                className: "flex justify-center items-center rounded-lg border-[1px] border-blue-secondary text-blue-secondary text-xl font-semibold px-9 py-2",
                children: "Chi tiết"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyCourse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5747:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(519);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var apis_course__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6849);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_atoms__WEBPACK_IMPORTED_MODULE_2__, apis_course__WEBPACK_IMPORTED_MODULE_4__]);
([_atoms__WEBPACK_IMPORTED_MODULE_2__, apis_course__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const OverviewCourse = ({ fitWidth , courseId , onClick  })=>{
    const [course, setCourse] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(undefined);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!courseId) return;
        (0,apis_course__WEBPACK_IMPORTED_MODULE_4__/* .getCourse */ .XR)(courseId).then((success)=>setCourse(success.data)).catch((error)=>console.log(error));
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        onClick: onClick,
        className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("flex items-center w-full p-4 rounded-lg border bg-white hover:shadow-xl"),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "min-w-[80px] w-[80px] h-[80px] rounded-2xl overflow-hidden",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .ImageOptimizing */ .UP, {
                    blurhash: "NVKKc$Ny4n%LNG%M~qxux]o2o2X8-;kW%LoeRjt7",
                    src: `${"https://node.edupath.ftisu.vn/"}${course?.course_img}`
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col flex-1 p-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "uppercase font-normal",
                        children: course?.course_name
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-xs text-[#b8b8b8]",
                        children: course?.description
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OverviewCourse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 545:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_cg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7865);
/* harmony import */ var react_icons_cg__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_cg__WEBPACK_IMPORTED_MODULE_4__);





const Pagination = ({ pageSize , className , currentPage , onChange  })=>{
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const handleClickPrev = ()=>{
        onChange(currentPage - 1);
    };
    const handleClickNext = ()=>{
        onChange(currentPage + 1);
    };
    const handleClickItem = (num)=>{
        onChange(num);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        const maxVisible = 4;
        const itemsCurrent = Array(pageSize).fill(0).map((_, index)=>index + 1);
        const totalPages = Math.ceil(itemsCurrent.length);
        let listNums = [];
        const isNearStart = currentPage - maxVisible / 2 - 1 <= 0;
        const isNearEnd = currentPage + maxVisible / 2 + 1 > totalPages;
        if (isNearStart || isNearEnd) {
            if (isNearStart) {
                listNums = itemsCurrent.slice(0, 5);
                if (pageSize - 1 > maxVisible) listNums.push("...");
            } else if (isNearEnd) {
                listNums = itemsCurrent.slice(totalPages - 5, totalPages);
                if (pageSize - 1 > maxVisible) listNums.unshift("...");
            }
        } else {
            const leftIndex = currentPage - 1 - maxVisible / 2;
            const rightIndex = currentPage + maxVisible / 2;
            listNums = itemsCurrent.slice(leftIndex < 0 ? 0 : leftIndex, rightIndex);
            if (pageSize - 1 > maxVisible) listNums.push("...");
            if (pageSize - 1 > maxVisible) listNums.unshift("...");
        }
        setItems(listNums);
    }, [
        pageSize,
        currentPage
    ]);
    const classNames = clsx__WEBPACK_IMPORTED_MODULE_1___default()("flex justify-center items-center w-full", {
        [className]: !!className
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classNames,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-fit mx-auto my-4 flex justify-between gap-4 select-none",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("flex cursor-pointer justify-center items-center rounded-md font-bold text-sm bg-gray-100 min-w-[40px] h-10", {
                        "opacity-25": currentPage - 1 < 1
                    }),
                    onClick: ()=>onChange(1),
                    disabled: currentPage - 1 < 1,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_cg__WEBPACK_IMPORTED_MODULE_4__.CgChevronDoubleLeft, {
                        size: 20
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("flex cursor-pointer justify-center items-center rounded-md font-bold text-sm bg-gray-100 min-w-[40px] h-10", {
                        "opacity-25": currentPage - 1 < 1
                    }),
                    onClick: handleClickPrev,
                    disabled: currentPage - 1 < 1,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_3__.MdOutlineNavigateBefore, {
                        size: 20
                    })
                }),
                items.map((num, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        onClick: ()=>Number(num) && handleClickItem(num),
                        className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("flex cursor-pointer justify-center items-center rounded-md font-bold text-sm bg-gray-100 min-w-[40px] h-10", {
                            "!bg-blue-500 text-white": num == currentPage,
                            "opacity-25": num === "..."
                        }),
                        children: num
                    }, num + index)),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("flex cursor-pointer justify-center items-center rounded-md font-bold text-sm bg-gray-100 min-w-[40px] h-10", {
                        "opacity-25": currentPage + 1 > pageSize
                    }),
                    onClick: handleClickNext,
                    disabled: currentPage + 1 > pageSize,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_3__.MdOutlineNavigateNext, {
                        size: 20
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("flex cursor-pointer justify-center items-center rounded-md font-bold text-sm bg-gray-100 min-w-[40px] h-10", {
                        "opacity-25": currentPage + 1 > pageSize
                    }),
                    onClick: ()=>onChange(pageSize),
                    disabled: currentPage + 1 > pageSize,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_cg__WEBPACK_IMPORTED_MODULE_4__.CgChevronDoubleRight, {
                        size: 20
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Pagination);


/***/ }),

/***/ 1969:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const PaymentTimer = ()=>{
    const [minutes, setMinutes] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(5);
    const [seconds, setSeconds] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const interval = setInterval(()=>{
            if (seconds > 0) {
                setSeconds(seconds - 1);
            } else {
                if (minutes === 0) {
                    clearInterval(interval);
                    // PaymentTimer has finished, do something here
                    console.log("PaymentTimer has finished!");
                } else {
                    setMinutes(minutes - 1);
                    setSeconds(59);
                }
            }
        }, 1000);
        return ()=>{
            clearInterval(interval);
        };
    }, [
        minutes,
        seconds
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
            children: [
                minutes.toString().padStart(2, "0"),
                ":",
                seconds.toString().padStart(2, "0")
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PaymentTimer);


/***/ }),

/***/ 5438:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MO": () => (/* reexport safe */ _MyCourseItem__WEBPACK_IMPORTED_MODULE_8__.Z),
/* harmony export */   "SN": () => (/* reexport safe */ _ActiveCourse__WEBPACK_IMPORTED_MODULE_7__.Z),
/* harmony export */   "T0": () => (/* reexport safe */ _Course__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "TT": () => (/* reexport safe */ _OverviewCourse__WEBPACK_IMPORTED_MODULE_6__.Z),
/* harmony export */   "iK": () => (/* reexport safe */ _ChatbotList__WEBPACK_IMPORTED_MODULE_5__.Z),
/* harmony export */   "jC": () => (/* reexport safe */ _MapItem__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "tl": () => (/* reexport safe */ _Pagination__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "uB": () => (/* reexport safe */ _PaymentTimer__WEBPACK_IMPORTED_MODULE_4__.Z)
/* harmony export */ });
/* harmony import */ var _MapItem__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8028);
/* harmony import */ var _Course__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7926);
/* harmony import */ var _ChatbotRecentItem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3475);
/* harmony import */ var _Pagination__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(545);
/* harmony import */ var _PaymentTimer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1969);
/* harmony import */ var _ChatbotList__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(788);
/* harmony import */ var _OverviewCourse__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5747);
/* harmony import */ var _ActiveCourse__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8831);
/* harmony import */ var _MyCourseItem__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(510);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MapItem__WEBPACK_IMPORTED_MODULE_0__, _Course__WEBPACK_IMPORTED_MODULE_1__, _ChatbotList__WEBPACK_IMPORTED_MODULE_5__, _OverviewCourse__WEBPACK_IMPORTED_MODULE_6__, _ActiveCourse__WEBPACK_IMPORTED_MODULE_7__, _MyCourseItem__WEBPACK_IMPORTED_MODULE_8__]);
([_MapItem__WEBPACK_IMPORTED_MODULE_0__, _Course__WEBPACK_IMPORTED_MODULE_1__, _ChatbotList__WEBPACK_IMPORTED_MODULE_5__, _OverviewCourse__WEBPACK_IMPORTED_MODULE_6__, _ActiveCourse__WEBPACK_IMPORTED_MODULE_7__, _MyCourseItem__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3145:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ChatbotSearch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5923);
/* harmony import */ var _ChatbotRecent__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9927);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ChatbotSearch__WEBPACK_IMPORTED_MODULE_2__]);
_ChatbotSearch__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const ChatbotAside = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("aside", {
        className: "h-full w-[289px] border-[1px] flex flex-col",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "h-[82px] w-full px-[12px] flex items-center border-b-[1px]",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ChatbotSearch__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-1 overflow-hidden relative",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ChatbotRecent__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChatbotAside);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6276:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_home__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6799);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(519);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _moleculers_ChatbotTyping__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9595);
/* harmony import */ var _contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8930);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5641);
/* harmony import */ var _moleculers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5438);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_atoms__WEBPACK_IMPORTED_MODULE_3__, _moleculers_ChatbotTyping__WEBPACK_IMPORTED_MODULE_5__, _contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_6__, react_hook_form__WEBPACK_IMPORTED_MODULE_7__, _moleculers__WEBPACK_IMPORTED_MODULE_8__]);
([_atoms__WEBPACK_IMPORTED_MODULE_3__, _moleculers_ChatbotTyping__WEBPACK_IMPORTED_MODULE_5__, _contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_6__, react_hook_form__WEBPACK_IMPORTED_MODULE_7__, _moleculers__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const ChatbotMain = (props)=>{
    const { listForm , chatForm , chatRef  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_6__/* .ChatbotContext */ .Hw);
    const handleSuggest = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((input)=>{
        _contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_6__/* .chatbotListener.emit */ .eq.emit("suggest", input);
        setTimeout(()=>{
            chatForm?.setValue("isBegin", false);
        }, 15000);
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex-1 flex flex-col",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "h-[82px] flex w-full gap-4 px-5 items-center border-b-[1px]",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-[65px] h-[65px] border-blue-secondary border-[1px] rounded-full p-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_home__WEBPACK_IMPORTED_MODULE_1__/* .BotIcon */ .Z8, {
                            className: "w-full h-full object-contain"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-1 gap-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col flex-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: " font-semibold text-lg",
                                        children: "Usagi"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: " text-sm text-1",
                                        children: "Trợ l\xfd AI"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .zx, {
                                        className: " bg-blue-secondary flex justify-center items-center !rounded-full w-[40px] h-[40px] !p-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__.AiOutlineSearch, {
                                            className: "text-xl w-full h-full"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .zx, {
                                        className: " bg-blue-secondary flex justify-center items-center !rounded-full w-[40px] h-[40px] !p-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__.AiOutlineClose, {
                                            className: "text-xl w-full h-full"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex-1 flex flex-col w-full overflow-hidden",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        ref: chatRef,
                        className: "flex-1 flex flex-col w-full p-4 overflow-y-auto gap-4 items-start",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_7__.Controller, {
                            control: chatForm?.control,
                            name: "list",
                            render: ({ field: chats  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_moleculers__WEBPACK_IMPORTED_MODULE_8__/* .ChatbotList */ .iK, {
                                    chats: chats.value
                                })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full bg-white",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_7__.Controller, {
                                control: chatForm?.control,
                                name: "isBegin",
                                render: ({ field: { value: isBegin  }  })=>{
                                    if (!isBegin) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "w-full px-4 pt-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                className: "text-sm",
                                                children: "C\xe2u hỏi gợi \xfd"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-full flex mt-2 gap-3 items-end overflow-x-auto",
                                                children: questionDefault.map((question, index)=>{
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .zx, {
                                                        onClick: ()=>handleSuggest(question),
                                                        className: "!bg-white border-[1px] border-gray-300 !text-gray-600",
                                                        children: question
                                                    }, index);
                                                })
                                            })
                                        ]
                                    });
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full flex items-center px-4 py-2",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_moleculers_ChatbotTyping__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    mode: "chatbot",
                                    className: ""
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
const questionDefault = [
    "Kỹ năng n\xe0o đang được tuyển dụng nhiều nhất ?",
    "Mức lương tham khảo của c\xf4ng ty FPT Software ?",
    "Mức lương của ng\xe0nh Game ?"
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChatbotMain);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9927:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_home__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6799);


const ChatbotRecent = (props)=>{
    // const { recents } = useContext(ChatbotContext);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: " flex-1 bg-cover blur-sm overflow-hidden",
                style: {
                    backgroundImage: `url(${_assets_home__WEBPACK_IMPORTED_MODULE_1__/* .chatBackground.src */ .qz.src})`
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: " absolute inset-0",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-[19px] py-[10px] text-white font-semibold text-lg",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: "Tin nhắn gần đ\xe2y"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-col w-full overflow-y-auto p-[12px] gap-2"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChatbotRecent);


/***/ }),

/***/ 5923:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(519);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_atoms__WEBPACK_IMPORTED_MODULE_2__]);
_atoms__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const ChatbotSearch = (props)=>{
    const [search, setSearch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(undefined);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex-1",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .TextFieldSearch */ .qJ, {
            value: search,
            className: " bg-gray-tertiary",
            onChange: (e)=>setSearch(e.target.value)
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChatbotSearch);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1679:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9030);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const Footer = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
        className: "bg-[#081E4C] text-white border-t mt-2 relative  py-8",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex items-center  flex-col gap-5 justify-center",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex divide-x-2 gap-6 items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                            src: "/logo.svg",
                            alt: "",
                            width: 200,
                            height: 200
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "px-6 text-xl font-medium w-56 ",
                            children: "Online Courses for IT market"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center gap-4 h-6 text-sm font-light opacity-80",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Careers"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "w-[1px] h-full bg-white"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Privacy Policy"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "w-[1px] h-full bg-white"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Privacy Policy"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    className: "text-sm font-light opacity-80",
                    children: [
                        "\xa9 2023 Information Systems Inc.",
                        " "
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 6003:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _redux_features_slices_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3169);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9030);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6915);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_vsc__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(382);
/* harmony import */ var react_icons_vsc__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_vsc__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(519);
/* harmony import */ var _ModalSurvey__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1072);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8982);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(cookies_next__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_atoms__WEBPACK_IMPORTED_MODULE_11__, _ModalSurvey__WEBPACK_IMPORTED_MODULE_12__]);
([_atoms__WEBPACK_IMPORTED_MODULE_11__, _ModalSurvey__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
"use client";














const navigation = {
    pages: [
        {
            name: "Trang chủ",
            href: "/"
        },
        {
            name: "Tất cả sản phẩm",
            href: "/products"
        },
        {
            name: "D\xe0nh cho nữ",
            href: "/products?type=women"
        },
        {
            name: "D\xe0nh cho nam",
            href: "/products?type=men"
        },
        // { name: 'Bộ phối', href: '/products' },
        {
            name: "Về ch\xfang tui",
            href: "/about"
        }
    ]
};
const Header = ()=>{
    const { asPath , push  } = useRouter();
    const modal = useSelector((state)=>state.modal);
    const user = useSelector((state)=>state.user);
    const dispatch = useDispatch();
    const [auth, setAuth] = useState();
    useEffect(()=>{
        setAuth(user);
    }, [
        user
    ]);
    const handleSignout = ()=>{
        deleteCookie("user");
    };
    return /*#__PURE__*/ _jsxs(_Fragment, {
        children: [
            modal.isOpen && /*#__PURE__*/ _jsx(ModalSurvey, {}),
            /*#__PURE__*/ _jsx("header", {
                className: "sticky bg-main-100 w-full z-[999] top-0 shadow-sm select-none",
                children: /*#__PURE__*/ _jsx("nav", {
                    "aria-label": "Top",
                    className: "h-16 py-4 flex items-center",
                    children: /*#__PURE__*/ _jsxs("div", {
                        className: "flex-1 flex items-center",
                        children: [
                            /*#__PURE__*/ _jsx("button", {
                                type: "button",
                                className: "rounded-md bg-white p-2 text-gray-400 lg:hidden"
                            }),
                            /*#__PURE__*/ _jsxs(Link, {
                                href: "/",
                                className: "flex items-center gap-2 px-10",
                                children: [
                                    /*#__PURE__*/ _jsx("span", {
                                        className: "bg-[url('/logo.png')] w-16 h-12 bg-no-repeat bg-contain"
                                    }),
                                    /*#__PURE__*/ _jsx("span", {
                                        className: "bg-[url('/logo_text.png')] w-28 h-4 bg-no-repeat bg-contain"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ _jsx("span", {
                                className: "h-8 w-px bg-gray-200",
                                "aria-hidden": "true"
                            }),
                            /*#__PURE__*/ _jsx("div", {
                                className: "flex h-full space-x-8 px-4",
                                children: /*#__PURE__*/ _jsx(Link, {
                                    href: "/mycourse",
                                    className: clsx("flex items-center text-sm font-medium text-white", {
                                        "!font-bold": asPath === "/mycourse"
                                    }),
                                    children: "Kh\xf3a học của t\xf4i"
                                })
                            }),
                            /*#__PURE__*/ _jsx("div", {
                                className: "flex items-center mx-4 h-8",
                                children: /*#__PURE__*/ _jsx(TextFieldSearch, {
                                    className: "flex-1 text-white"
                                })
                            }),
                            /*#__PURE__*/ _jsx("section", {
                                className: "ml-auto flex items-center px-8",
                                children: /*#__PURE__*/ _jsxs("div", {
                                    className: "hidden lg:flex lg:flex-1 lg:items-center lg:justify-end lg:space-x-6",
                                    children: [
                                        auth?.token ? /*#__PURE__*/ _jsxs(_Fragment, {
                                            children: [
                                                /*#__PURE__*/ _jsx(BsCart3, {
                                                    size: 20,
                                                    onClick: ()=>push("/cart"),
                                                    className: "text-xs font-medium text-white hover:text-gray-100",
                                                    color: "white"
                                                }),
                                                /*#__PURE__*/ _jsx(VscBell, {
                                                    size: 20,
                                                    className: "text-xs font-medium text-white hover:text-gray-100",
                                                    onClick: ()=>dispatch(setModal({
                                                            isOpen: true
                                                        })),
                                                    color: "white"
                                                }),
                                                /*#__PURE__*/ _jsx("span", {
                                                    className: "h-8 w-px bg-gray-200",
                                                    "aria-hidden": "true"
                                                }),
                                                /*#__PURE__*/ _jsxs("div", {
                                                    id: "user",
                                                    className: "flex items-center gap-2 relative",
                                                    children: [
                                                        /*#__PURE__*/ _jsx(Image, {
                                                            className: "object-cover w-8 h-8 rounded-full",
                                                            src:  false || "https://shorturl.at/aNQT2",
                                                            alt: "",
                                                            unoptimized: true,
                                                            width: 32,
                                                            height: 32,
                                                            "aria-hidden": "true"
                                                        }),
                                                        /*#__PURE__*/ _jsx("p", {
                                                            className: "text-xs font-medium text-white",
                                                            children: auth?.name
                                                        }),
                                                        /*#__PURE__*/ _jsx(BiChevronDown, {
                                                            size: 14,
                                                            color: "white"
                                                        }),
                                                        /*#__PURE__*/ _jsx("div", {
                                                            id: "dropdown",
                                                            className: "z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow absolute top-[30px] right-0 translate-x-1/2 w-fit",
                                                            children: /*#__PURE__*/ _jsxs("ul", {
                                                                className: "py-2 text-sm text-gray-700",
                                                                "aria-labelledby": "dropdownDefaultButton",
                                                                children: [
                                                                    /*#__PURE__*/ _jsx("li", {
                                                                        children: /*#__PURE__*/ _jsx("a", {
                                                                            href: "#",
                                                                            className: "block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white",
                                                                            children: "Dashboard"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ _jsx("li", {
                                                                        children: /*#__PURE__*/ _jsx("a", {
                                                                            href: "#",
                                                                            className: "block px-4 py-2 hover:bg-gray-100",
                                                                            children: "Settings"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ _jsx("li", {
                                                                        children: /*#__PURE__*/ _jsx("a", {
                                                                            href: "#",
                                                                            className: "block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white",
                                                                            children: "Earnings"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ _jsx("li", {
                                                                        children: /*#__PURE__*/ _jsx("a", {
                                                                            onClick: handleSignout,
                                                                            href: "/",
                                                                            className: "block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white",
                                                                            children: "Sign out"
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        }) : /*#__PURE__*/ _jsx(Button, {
                                            onClick: ()=>push("/login"),
                                            className: "!bg-white !text-[#0066FF] uppercase",
                                            children: "Đăng nhập"
                                        }),
                                        /*#__PURE__*/ _jsxs("div", {
                                            className: "flex items-center gap-2 bg-[#1414681A] rounded-full p-2",
                                            children: [
                                                /*#__PURE__*/ _jsx("span", {
                                                    className: "bg-[url('/vietnam.png')] rounded-full w-4 h-4 bg-no-repeat bg-contain"
                                                }),
                                                /*#__PURE__*/ _jsx(BiChevronDown, {
                                                    size: 14,
                                                    color: "white"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Header)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1379:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var firebase_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3392);
/* harmony import */ var _apis_firebase__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3516);
/* harmony import */ var _components_atoms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(519);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_storage__WEBPACK_IMPORTED_MODULE_2__, _apis_firebase__WEBPACK_IMPORTED_MODULE_3__, _components_atoms__WEBPACK_IMPORTED_MODULE_4__]);
([firebase_storage__WEBPACK_IMPORTED_MODULE_2__, _apis_firebase__WEBPACK_IMPORTED_MODULE_3__, _components_atoms__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const ImageComponent = ({ urldb  })=>{
    const [imageUrl, setImageUrl] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(urldb);
    const base_link = "gs://edupath-dfcd4.appspot.com/";
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const getImageUrl = async ()=>{
            try {
                let url;
                if (urldb) {
                    url = await (0,firebase_storage__WEBPACK_IMPORTED_MODULE_2__.getDownloadURL)((0,firebase_storage__WEBPACK_IMPORTED_MODULE_2__.ref)(_apis_firebase__WEBPACK_IMPORTED_MODULE_3__/* .storage */ .tO, base_link + urldb));
                } else {
                    url = await (0,firebase_storage__WEBPACK_IMPORTED_MODULE_2__.getDownloadURL)((0,firebase_storage__WEBPACK_IMPORTED_MODULE_2__.ref)(_apis_firebase__WEBPACK_IMPORTED_MODULE_3__/* .storage */ .tO, base_link + " "));
                }
                if (url) setImageUrl(url);
            } catch (error) {
                console.error("Error getting image URL from Firebase Storage:", error);
            }
        };
        getImageUrl();
    }, [
        urldb
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: imageUrl && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_atoms__WEBPACK_IMPORTED_MODULE_4__/* .ImageOptimizing */ .UP, {
            objectFit: "contain",
            src: imageUrl,
            blurhash: "NVKKc$Ny4n%LNG%M~qxux]o2o2X8-;kW%LoeRjt7"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageComponent);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1019:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9030);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_home__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6799);




const ModalChoosen = (props)=>{
    const { prediction , handleChoose  } = props;
    const selectMaintype = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((maintype)=>{
        switch(maintype){
            case "FrontEnd":
                return _assets_home__WEBPACK_IMPORTED_MODULE_3__/* .frontend.src */ .tQ.src;
            case "BackEnd":
                return _assets_home__WEBPACK_IMPORTED_MODULE_3__/* .backend.src */ .y3.src;
            case "DevOps":
                return _assets_home__WEBPACK_IMPORTED_MODULE_3__/* .devops.src */ .Hk.src;
            case "Android":
                return _assets_home__WEBPACK_IMPORTED_MODULE_3__/* .android.src */ .tW.src;
            case "Flutter":
                return _assets_home__WEBPACK_IMPORTED_MODULE_3__/* .flutter.src */ .kD.src;
            case "BlockChain":
                return _assets_home__WEBPACK_IMPORTED_MODULE_3__/* .blockchain.src */ .tb.src;
            default:
                return _assets_home__WEBPACK_IMPORTED_MODULE_3__/* .blockchain.src */ .tb.src;
        }
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col items-center gap-8 flex-1 p-[29px] w-full overflow-auto",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: "font-bold text-2xl text-center",
                children: "Lộ tr\xecnh đ\xea xuất"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col items-stretch gap-7",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "Chọn 1 lộ tr\xecnh dưới đ\xe2y để bắt đầu h\xe0nh tr\xecnh của bạn"
                    }),
                    prediction?.map((item)=>{
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "h-[105px] flex items-center",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    className: "flex shadow-lg p-[7px] rounded-2xl items-center",
                                    onClick: ()=>handleChoose(item.maintype_id),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            alt: "main_type",
                                            src: selectMaintype(item.maintype),
                                            width: 100,
                                            height: 50,
                                            className: " rounded-2xl h-[90px] w-[171px]"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                            className: "px-[44px] text-[#103D9C] text-xl",
                                            children: item.maintype
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: " shrink-0 text-center w-[160px] text-2xl ",
                                    children: [
                                        item.percent?.toFixed(2),
                                        " %"
                                    ]
                                })
                            ]
                        }, item.maintype_id);
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-2 items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                children: "Lộ tr\xecnh kh\xe1c"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1 h-[1px] bg-black"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full overflow-hidden",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex gap-5 overflow-y-auto py-8 px-1",
                            children: [
                                1,
                                2,
                                3,
                                4,
                                5
                            ].map((item)=>{
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "h-[70px] flex items-center shrink-0",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                        className: "flex shadow-lg p-[7px] rounded-2xl items-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                alt: "main_type",
                                                src: selectMaintype(""),
                                                width: 70,
                                                height: 30,
                                                className: " rounded-2xl h-[90px] w-[171px] object-cover"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                className: "px-[22px] text-[#103D9C] text-xl",
                                                children: "Blockchain"
                                            })
                                        ]
                                    })
                                }, item);
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModalChoosen);


/***/ }),

/***/ 6606:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ModalChoosen__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1019);




const ModalRechoose = (props)=>{
    const [prediction, setPrediction] = useState([]);
    const handleChoose = ()=>{};
    return /*#__PURE__*/ _jsx("div", {
        className: "bg-[#50505072] fixed top-0 bottom-0 z-50 h-screen w-screen flex items-center justify-center",
        children: /*#__PURE__*/ _jsx("div", {
            className: clsx("w-2/3 h-4/5 bg-white flex rounded-2xl", {}),
            children: /*#__PURE__*/ _jsx(ModalChoosen, {
                prediction: prediction,
                handleChoose: handleChoose
            })
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ModalRechoose)));


/***/ }),

/***/ 7973:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _moleculers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5438);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8547);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_gr__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var apis_roadmap__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1482);
/* harmony import */ var _types_course__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5933);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__, _moleculers__WEBPACK_IMPORTED_MODULE_5__, apis_roadmap__WEBPACK_IMPORTED_MODULE_7__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_2__, _moleculers__WEBPACK_IMPORTED_MODULE_5__, apis_roadmap__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const ModalSurvey = ({ onClose , detailId  })=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const [list, setList] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        const bodyElement = document.querySelector("body");
        if (bodyElement) bodyElement.classList.add("!overflow-hidden", "relative");
        return ()=>{
            if (bodyElement) bodyElement.classList.remove("!overflow-hidden");
        };
    }, []);
    const [filterLevel, setFilterLevel] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(_types_course__WEBPACK_IMPORTED_MODULE_8__/* .ELevel.ALL_LEVELS */ .aU.ALL_LEVELS);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        lodash__WEBPACK_IMPORTED_MODULE_9___default().throttle(()=>{
            (0,apis_roadmap__WEBPACK_IMPORTED_MODULE_7__/* .getCoursesSimilarTag */ .O)(detailId).then((success)=>setList(success.data)).catch((error)=>console.log(error));
        }, 1000)();
    }, [
        detailId
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bg-[#50505072] fixed top-0 bottom-0 z-50 h-screen w-screen flex items-center justify-center",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-2/3 h-4/5 bg-white flex flex-col overflow-hidden rounded-lg p-2",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center justify-between gap-2 p-8",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "font-semibold text-2xl",
                                    children: "Basic Operations"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                        width: "21",
                                        height: "21",
                                        viewBox: "0 0 21 21",
                                        fill: "none",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                cx: "10.5",
                                                cy: "10.5",
                                                r: "10.5",
                                                fill: "#B4DFFF"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                                                "clip-path": "url(#clip0_442_2258)",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        "fill-rule": "evenodd",
                                                        "clip-rule": "evenodd",
                                                        d: "M5.8125 8H7.0625C7.58 8 8 8.42 8 8.9375V15.1875C8 15.705 7.58 16.125 7.0625 16.125H5.8125C5.295 16.125 4.875 15.705 4.875 15.1875V8.9375C4.875 8.42 5.295 8 5.8125 8Z",
                                                        fill: "#2F80ED"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        "fill-rule": "evenodd",
                                                        "clip-rule": "evenodd",
                                                        d: "M13.2144 16.1251H9.25C8.55937 16.1251 8 15.5657 8 14.8751V8.7201C8 8.25698 8.17125 7.8101 8.48125 7.46573L10.0156 5.76135L10.2525 4.3351C10.3594 3.6926 11.1244 3.41948 11.6219 3.8401C12.025 4.18073 12.375 4.68635 12.375 5.4151C12.375 6.51885 11.75 8.0001 11.75 8.0001H14.875C15.9106 8.0001 16.75 8.83948 16.75 9.8751V10.7076C16.75 10.9826 16.6894 11.2545 16.5725 11.5032L14.9119 15.0457C14.6031 15.7045 13.9419 16.1251 13.2144 16.1251Z",
                                                        fill: "#2F80ED",
                                                        "fill-opacity": "0.5"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("clipPath", {
                                                    id: "clip0_442_2258",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                                        width: "15",
                                                        height: "15",
                                                        fill: "white",
                                                        transform: "translate(3 3)"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                            whileTap: {
                                scale: 0.75
                            },
                            className: "cursor-pointer",
                            onClick: onClose,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_6__.GrClose, {
                                size: 20
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex w-full",
                    children: Object.keys(_types_course__WEBPACK_IMPORTED_MODULE_8__/* .ELevel */ .aU).filter((x)=>Number.isNaN(Number(x)) && x !== "NONE").map((key)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("flex-1 p-4 flex items-center justify-center bg-[#F3F3F3] text-[#C0C0C0] text-sm border-b-2 overflow-hidden cursor-pointer", {
                                "!bg-white !text-[#3D5AF1] font-bold !text-base border-2 rounded-t-lg border-b-transparent -mt-4 transition-all": filterLevel === _types_course__WEBPACK_IMPORTED_MODULE_8__/* .ELevel */ .aU[key]
                            }),
                            onClick: ()=>setFilterLevel(_types_course__WEBPACK_IMPORTED_MODULE_8__/* .ELevel */ .aU[key]),
                            children: key
                        }, key);
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.AnimatePresence, {
                    mode: "wait",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                        className: "flex-1 h-full py-8 px-12 border-2 border-t-transparent rounded-b-lg",
                        initial: {
                            y: 10,
                            opacity: 0
                        },
                        animate: {
                            y: 0,
                            opacity: 1
                        },
                        exit: {
                            y: -10,
                            opacity: 0
                        },
                        transition: {
                            duration: 0.2
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex justify-between overflow-x-auto w-full gap-4 py-5",
                            children: list.filter((x)=>filterLevel === _types_course__WEBPACK_IMPORTED_MODULE_8__/* .ELevel.ALL_LEVELS */ .aU.ALL_LEVELS || x.course_level === filterLevel).map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                                    initial: {
                                        opacity: 0,
                                        scale: 0.5
                                    },
                                    animate: {
                                        opacity: 1,
                                        scale: 1
                                    },
                                    transition: {
                                        duration: 0.8,
                                        delay: 0.1 * index,
                                        ease: [
                                            0,
                                            0.71,
                                            0.2,
                                            1.01
                                        ]
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_moleculers__WEBPACK_IMPORTED_MODULE_5__/* .Course */ .T0, {
                                        fitWidth: true,
                                        courseId: item._id
                                    }, item._id)
                                }))
                        })
                    }, filterLevel)
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_3__.memo)(ModalSurvey));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1072:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _types_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2785);
/* harmony import */ var _utils_string__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2239);
/* harmony import */ var _iscv_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7608);
/* harmony import */ var _iscv_toast__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_iscv_toast__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var apis_recommend__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3359);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8982);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(cookies_next__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6197);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9030);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5641);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5452);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_icons_rx__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(519);
/* harmony import */ var _moleculers_ChatbotTyping__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9595);
/* harmony import */ var _atoms_Loading__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6998);
/* harmony import */ var _ModalChoosen__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1019);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([apis_recommend__WEBPACK_IMPORTED_MODULE_3__, framer_motion__WEBPACK_IMPORTED_MODULE_6__, react_hook_form__WEBPACK_IMPORTED_MODULE_10__, _atoms__WEBPACK_IMPORTED_MODULE_12__, _moleculers_ChatbotTyping__WEBPACK_IMPORTED_MODULE_13__]);
([apis_recommend__WEBPACK_IMPORTED_MODULE_3__, framer_motion__WEBPACK_IMPORTED_MODULE_6__, react_hook_form__WEBPACK_IMPORTED_MODULE_10__, _atoms__WEBPACK_IMPORTED_MODULE_12__, _moleculers_ChatbotTyping__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const QUESTIONS = [
    {
        name: "q1",
        type: "button",
        questions: [
            "Ch\xe0o bạn, m\xecnh l\xe0 Usagi - Trợ l\xfd AI của EduPath. M\xecnh cần một số th\xf4ng tin từ bạn để tạo c\xe1c lộ tr\xecnh theo lĩnh vực ph\xf9 hợp nhất với bạn.",
            "Vui l\xf2ng cho m\xecnh biết bạn đang l\xe0 đối tượng n\xe0o"
        ],
        options: [
            {
                value: "Học sinh",
                label: "Học sinh"
            },
            {
                value: "Sinh vi\xean",
                label: "Sinh vi\xean"
            },
            {
                value: "Người đi l\xe0m",
                label: "Người đi l\xe0m"
            }
        ]
    },
    {
        name: "q2",
        type: "button",
        questions: [
            "Bạn đ\xe3 c\xf3 kinh nghiệm về lập tr\xecnh chưa?"
        ],
        options: [
            {
                value: "Rồi",
                label: "Rồi"
            },
            {
                value: "Chưa c\xf3",
                label: "Chưa c\xf3"
            }
        ]
    },
    {
        name: "q3",
        type: "input",
        questions: [
            "H\xe3y liệt k\xea một số kỹ năng hoặc ng\xf4n ngữ lập tr\xecnh m\xe0 bạn từng sử dụng nh\xe9"
        ]
    }
];
const ModalSurvey = ()=>{
    const bottomRef = (0,react__WEBPACK_IMPORTED_MODULE_9__.useRef)(null);
    const [onForcus, setOnForcus] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [recommendStatus, setRecommendStatus] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(_types_index__WEBPACK_IMPORTED_MODULE_1__/* .ERecommendStatus.NONE */ .X.NONE);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const selectionRef = (0,react__WEBPACK_IMPORTED_MODULE_9__.useRef)(null);
    const list = (0,react__WEBPACK_IMPORTED_MODULE_9__.useRef)([]);
    // useEffect(() => {
    // 	const bodyElement = document.querySelector("body");
    // 	if (bodyElement) bodyElement.classList.add("!overflow-hidden", "relative");
    // 	return () => {
    // 		if (bodyElement) bodyElement.classList.remove("!overflow-hidden");
    // 	};
    // }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        (0,apis_recommend__WEBPACK_IMPORTED_MODULE_3__/* .listTag */ .QL)().then((success)=>list.current = success.data).catch((error)=>console.log(error));
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        const userData = (0,cookies_next__WEBPACK_IMPORTED_MODULE_5__.getCookie)("user")?.toString();
        if (!userData) return;
        const userId = JSON.parse(userData).id;
        if (!userId) return;
        (0,apis_recommend__WEBPACK_IMPORTED_MODULE_3__/* .checkStatus */ .XZ)(userId).then((success)=>{
            setRecommendStatus(success.data.status);
            setPrediction(success.data.prediction);
        }).catch((error)=>console.log(error));
    }, []);
    const [questions, setQuestions] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)([
        QUESTIONS[0]
    ]);
    const toast = (0,_iscv_toast__WEBPACK_IMPORTED_MODULE_2__.useToast)();
    const [response, setResponse] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)();
    const { control , setValue , getValues , resetField , handleSubmit  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_10__.useForm)({
        defaultValues: {
            programings: [],
            text: undefined,
            suggestions: []
        }
    });
    const { fields , remove , append  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_10__.useFieldArray)({
        control,
        name: "programings"
    });
    const [prediction, setPrediction] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(undefined);
    const loading = (0,_atoms_Loading__WEBPACK_IMPORTED_MODULE_14__/* .useLoading */ .r)();
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        if (!selectionRef.current) return;
        function handleClickOutside(event) {
            if (selectionRef.current && !selectionRef.current.contains(event.target)) {
                console.log("first");
                setValue("suggestions", []);
            }
        }
        // Bind the event listener
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>{
            // Unbind the event listener on clean up
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [
        selectionRef
    ]);
    const handelNextQuestion = (value, name)=>{
        setResponse((r)=>({
                ...r,
                [name]: [
                    ...value
                ]
            }));
        if (questions.length < QUESTIONS.length) setQuestions((q)=>[
                ...q,
                QUESTIONS[q.length]
            ]);
    };
    const scrollToBottom = ()=>{
        bottomRef.current?.scrollIntoView({
            behavior: "smooth"
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        const time = setTimeout(()=>{
            scrollToBottom();
        }, 300);
        return ()=>clearTimeout(time);
    }, [
        questions,
        onForcus
    ]);
    const handleSuggestions = (e)=>{
        if (!e) {
            resetField("suggestions");
            return;
        }
        const result = (0,_utils_string__WEBPACK_IMPORTED_MODULE_16__/* .searchSubstring */ .r)(list.current, e).slice(0, 3).reverse();
        setValue("suggestions", result);
    };
    const onSubmit = async (data)=>{
        if (!data.programings.length) return;
        loading.open();
        await (0,apis_recommend__WEBPACK_IMPORTED_MODULE_3__/* .processRecommend */ .AT)(data.programings).then((success)=>{
            const data = success.data;
            setRecommendStatus(_types_index__WEBPACK_IMPORTED_MODULE_1__/* .ERecommendStatus.CHOOSEN */ .X.CHOOSEN);
            setPrediction(data);
        }).catch((error)=>console.log(error));
        loading.close();
    };
    const handleChoose = async (choosen)=>{
        loading.open();
        await (0,apis_recommend__WEBPACK_IMPORTED_MODULE_3__/* .chooseMaintype */ .Bg)(choosen).then((success)=>{
            toast.success();
            router.push("/roadmap");
        }).catch((error)=>{
            console.log(error);
            toast.error;
        });
        loading.close();
    };
    if (!recommendStatus || recommendStatus === _types_index__WEBPACK_IMPORTED_MODULE_1__/* .ERecommendStatus.DONE */ .X.DONE) return null;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bg-[#50505072] fixed inset-0 bg-whe z-50 flex items-center justify-center",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "fixed bg-white flex rounded-2xl top-1/2 left-1/2 -translate-x-1/2 -translate-y-[45%] rounnded-2xl  w-[70%] h-[80%] overflow-hidden",
            children: [
                recommendStatus === _types_index__WEBPACK_IMPORTED_MODULE_1__/* .ERecommendStatus.FIRST_TIME */ .X.FIRST_TIME && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: " bg-[#D8EDFF] h-full relative flex flex-col",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full flex flex-col gap-2 p-10",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                            className: "text-2xl text-[#16325C] font-bold text-center",
                                            children: "CH\xc0O MỪNG ĐẾN VỚI EDUPATH"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-xs text-[#666666] leading-6 mt-3",
                                            children: "Vui l\xf2ng ho\xe0n th\xe0nh khảo s\xe1t nhanh c\xf9ng Usagi để EduPath gi\xfap bạn tạo lộ tr\xecnh học tập ri\xeang ph\xf9 hợp nh\xe9!"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex-1 flex items-center justify-center flex-col gap-2",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: "text-xs font-semibold text-[#16325C]",
                                            children: [
                                                response && Object.keys(response)?.length || 0,
                                                "/",
                                                QUESTIONS?.length || 0,
                                                " c\xe2u đ\xe3 ho\xe0n th\xe0nh"
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-1/2 h-2 bg-white relative rounded-full overflow-hidden",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: clsx__WEBPACK_IMPORTED_MODULE_4___default()("h-2 bg-[#5EB4FF] absolute top-0 left-0 transition-all ease-linear duration-700", {
                                                    "w-0": response && Object.keys(response).length === 0,
                                                    "w-1/3": response && Object.keys(response).length === 1,
                                                    "w-2/3": response && Object.keys(response).length === 2,
                                                    "w-3/3": response && Object.keys(response).length === 3
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "bg-[url('/bg_info.png')] absolute -bottom-1 w-full h-[70px] bg-cover bg-no-repeat "
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex-[3] h-full flex flex-col relative",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "bg-[#103D9C] h-16 flex items-center justify-start gap-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex -mr-2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_rx__WEBPACK_IMPORTED_MODULE_11__.RxDotFilled, {
                                                size: 30,
                                                color: "#34A853"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "h-[50px] w-[50px] p-1 rounded-full bg-white",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                src: "/usagi.svg",
                                                alt: "usagi",
                                                className: "w-full h-full",
                                                width: 100,
                                                height: 100
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                    className: "font-medium text-base text-white",
                                                    children: "Usagi"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-xs italic text-white font-light",
                                                    children: "Trợ l\xfd AI"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex-1 h-full p-3 flex flex-col gap-3 overflow-x-auto ",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                questions.map((question)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: clsx__WEBPACK_IMPORTED_MODULE_4___default()("flex flex-col gap-3", {
                                                        }),
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__.AnimatePresence, {
                                                                mode: "wait",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.div, {
                                                                    initial: {
                                                                        y: 10,
                                                                        opacity: 0
                                                                    },
                                                                    animate: {
                                                                        y: 0,
                                                                        opacity: 1
                                                                    },
                                                                    exit: {
                                                                        y: -10,
                                                                        opacity: 0
                                                                    },
                                                                    transition: {
                                                                        duration: 0.2
                                                                    },
                                                                    className: "flex items-center gap-2",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "self-start h-[50px] w-[50px] p-1 rounded-full bg-white",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                                                src: "/usagi.svg",
                                                                                alt: "usagi",
                                                                                className: "w-full h-full",
                                                                                width: 100,
                                                                                height: 100
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "flex flex-col w-2/3 gap-3",
                                                                            children: question?.questions.map((content)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                    className: "bg-[#F5F5F5] p-2 text-sm rounded-lg",
                                                                                    children: content
                                                                                }, content))
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "flex gap-3",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "self-start w-[50px] p-1 rounded-full bg-white"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "flex gap-3",
                                                                        children: question?.options?.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_12__/* .Button */ .zx, {
                                                                                onClick: ()=>handelNextQuestion([
                                                                                        item.value
                                                                                    ], question.name),
                                                                                className: "!bg-[#103D9C]",
                                                                                children: item.label
                                                                            }, item.label))
                                                                    })
                                                                ]
                                                            }),
                                                            response?.[question?.name] && response?.[question?.name]?.map((res)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "flex justify-end",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_12__/* .Button */ .zx, {
                                                                        className: "!bg-[#103D9C] w-fit",
                                                                        children: res
                                                                    })
                                                                }, res))
                                                        ]
                                                    }, question.name)),
                                                questions[questions.length - 1]?.type == "input" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    ref: bottomRef,
                                                    className: "w-full flex flex-col gap-2 relative",
                                                    onFocus: ()=>setOnForcus((r)=>!r),
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            ref: selectionRef,
                                                            className: " absolute bottom-[80px] left-[-12px] right-0 gap-2 flex flex-col items-start",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_10__.Controller, {
                                                                name: "suggestions",
                                                                control: control,
                                                                render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "flex flex-col gap-2 items-stretch bg-white rounded-xl p-3",
                                                                        children: field.value.map((suggestion)=>{
                                                                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_12__/* .Button */ .zx, {
                                                                                mode: "default",
                                                                                className: "!bg-blue-secondary",
                                                                                onClick: ()=>{
                                                                                    if (!getValues("programings").includes(suggestion)) append(suggestion);
                                                                                },
                                                                                children: suggestion
                                                                            }, suggestion);
                                                                        })
                                                                    })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_10__.Controller, {
                                                            name: "text",
                                                            control: control,
                                                            render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_moleculers_ChatbotTyping__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                                    value: field.value,
                                                                    onChange: (e)=>{
                                                                        field.onChange(e);
                                                                        handleSuggestions(e.target.value);
                                                                    },
                                                                    onSubmit: handleSubmit(onSubmit)
                                                                })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_10__.Controller, {
                                                            name: "programings",
                                                            control: control,
                                                            render: ({ field  })=>{
                                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "flex w-full gap-2 h-[40px]",
                                                                    children: fields.map((skill, index)=>{
                                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_10__.Controller, {
                                                                            control: control,
                                                                            name: `programings.${index}`,
                                                                            render: ({ field: fieldItem  })=>{
                                                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_12__/* .Button */ .zx, {
                                                                                    mode: "default",
                                                                                    className: "!bg-blue-secondary",
                                                                                    isCloseToggle: true,
                                                                                    onClick: ()=>remove(index),
                                                                                    children: fieldItem.value
                                                                                });
                                                                            }
                                                                        }, skill.id);
                                                                    })
                                                                });
                                                            }
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            ref: bottomRef
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                recommendStatus === _types_index__WEBPACK_IMPORTED_MODULE_1__/* .ERecommendStatus.CHOOSEN */ .X.CHOOSEN && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalChoosen__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                    prediction: prediction,
                    handleChoose: handleChoose
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModalSurvey);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2706:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$_": () => (/* reexport safe */ _Footer__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "Xz": () => (/* reexport safe */ _ModalRoadMap__WEBPACK_IMPORTED_MODULE_4__.Z),
/* harmony export */   "cu": () => (/* reexport safe */ _ImageComponent__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "oJ": () => (/* reexport safe */ _ModalSurvey__WEBPACK_IMPORTED_MODULE_2__.Z),
/* harmony export */   "s8": () => (/* reexport safe */ _ChatbotAside__WEBPACK_IMPORTED_MODULE_5__.Z)
/* harmony export */ });
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6003);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1679);
/* harmony import */ var _ModalSurvey__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1072);
/* harmony import */ var _ImageComponent__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1379);
/* harmony import */ var _ModalRoadMap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7973);
/* harmony import */ var _ChatbotAside__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3145);
/* harmony import */ var _ChatbotSearch__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5923);
/* harmony import */ var _ModalChoosen__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1019);
/* harmony import */ var _ModalRechoose__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6606);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Header__WEBPACK_IMPORTED_MODULE_0__, _ModalSurvey__WEBPACK_IMPORTED_MODULE_2__, _ImageComponent__WEBPACK_IMPORTED_MODULE_3__, _ModalRoadMap__WEBPACK_IMPORTED_MODULE_4__, _ChatbotAside__WEBPACK_IMPORTED_MODULE_5__, _ChatbotSearch__WEBPACK_IMPORTED_MODULE_6__]);
([_Header__WEBPACK_IMPORTED_MODULE_0__, _ModalSurvey__WEBPACK_IMPORTED_MODULE_2__, _ImageComponent__WEBPACK_IMPORTED_MODULE_3__, _ModalRoadMap__WEBPACK_IMPORTED_MODULE_4__, _ChatbotAside__WEBPACK_IMPORTED_MODULE_5__, _ChatbotSearch__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8723:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(519);
/* harmony import */ var _moleculers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5438);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _apis_search__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6607);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _atoms__WEBPACK_IMPORTED_MODULE_3__, _moleculers__WEBPACK_IMPORTED_MODULE_4__, _apis_search__WEBPACK_IMPORTED_MODULE_6__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _atoms__WEBPACK_IMPORTED_MODULE_3__, _moleculers__WEBPACK_IMPORTED_MODULE_4__, _apis_search__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const AllCourses = ({ stateStore  })=>{
    const loading = (0,_atoms__WEBPACK_IMPORTED_MODULE_3__/* .useLoading */ .r$)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (async ()=>{
            loading.open();
            await (0,_apis_search__WEBPACK_IMPORTED_MODULE_6__/* .searchCourses */ .B)({}).then((success)=>stateStore.setValue("courses", success.data.map((x)=>x._id))).catch((error)=>console.log(error));
            loading.close();
        })();
    }, []);
    const handleSearch = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        lodash__WEBPACK_IMPORTED_MODULE_5___default().throttle(()=>{
            const search = stateStore.getValues("search");
            (0,_apis_search__WEBPACK_IMPORTED_MODULE_6__/* .searchCourses */ .B)({
                search: search
            }).then((success)=>stateStore.setValue("courses", success.data.map((x)=>x._id))).catch((error)=>console.log(error));
        }, 300)();
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col items-center overflow-x-hidden",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-44 flex items-center justify-center bg-[url('/bg-all-courses.png')] bg-cover flex-col gap-2",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-white rounded-lg flex items-center justify-center h-12 w-2/3 p-4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                                name: "search",
                                control: stateStore.control,
                                render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_3__/* .TextField */ .nv, {
                                        ...field,
                                        className: "flex-1 !border-none !h-full outline-none",
                                        placeholder: "Search your favourite course"
                                    })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .zx, {
                                className: "flex items-center justify-center !bg-[#0066FF]",
                                children: "Search"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center justify-center gap-4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                                name: "type",
                                control: stateStore.control,
                                render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_3__/* .Select */ .Ph, {
                                        placeHolder: "Type",
                                        options: [],
                                        ...field
                                    })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                                name: "type",
                                control: stateStore.control,
                                render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_3__/* .Select */ .Ph, {
                                        placeHolder: "Author",
                                        options: [],
                                        ...field,
                                        isClearable: true
                                    })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                                name: "type",
                                control: stateStore.control,
                                render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_3__/* .Select */ .Ph, {
                                        placeHolder: "Price",
                                        options: [
                                            {
                                                label: "a",
                                                value: ""
                                            }
                                        ],
                                        ...field
                                    })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                                name: "type",
                                control: stateStore.control,
                                render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_3__/* .Select */ .Ph, {
                                        placeHolder: "Language",
                                        options: [],
                                        ...field
                                    })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                                name: "type",
                                control: stateStore.control,
                                render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_3__/* .Select */ .Ph, {
                                        placeHolder: "Level",
                                        options: [],
                                        ...field
                                    })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "max-w-full min-w-[70%] mt-10 flex flex-col items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "grid grid-cols-4 grid-rows-2 gap-4 content-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                            control: stateStore.control,
                            name: "courses",
                            render: ({ field: { value: courses  }  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: courses.map((course)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_moleculers__WEBPACK_IMPORTED_MODULE_4__/* .Course */ .T0, {
                                            fitWidth: true,
                                            courseId: course
                                        }, course))
                                })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mt-5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_moleculers__WEBPACK_IMPORTED_MODULE_4__/* .Pagination */ .tl, {
                            onChange: (e)=>1,
                            pageSize: 5,
                            currentPage: 3
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AllCourses);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6509:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _organisms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2706);
/* harmony import */ var _contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8930);
/* harmony import */ var _organisms_ChatbotMain__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6276);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_organisms__WEBPACK_IMPORTED_MODULE_2__, _contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_3__, _organisms_ChatbotMain__WEBPACK_IMPORTED_MODULE_4__]);
([_organisms__WEBPACK_IMPORTED_MODULE_2__, _contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_3__, _organisms_ChatbotMain__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const Chatbot = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-screen h-[calc(100vh-64px)] overflow-hidden flex items-stretch",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_organisms__WEBPACK_IMPORTED_MODULE_2__/* .ChatbotAside */ .s8, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_organisms_ChatbotMain__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
        ]
    });
};
const Wrapper = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_ChatbotContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Chatbot, {})
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Wrapper);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6670:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(519);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _organisms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2706);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _moleculers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5438);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var apis_payment__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8088);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6915);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5641);
/* harmony import */ var _assets_detail__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(632);
/* harmony import */ var _iscv_toast__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7608);
/* harmony import */ var _iscv_toast__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_iscv_toast__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var apis_review__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4002);
/* harmony import */ var _utils_date__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(3426);
/* harmony import */ var _apis_course__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(6849);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_atoms__WEBPACK_IMPORTED_MODULE_2__, _organisms__WEBPACK_IMPORTED_MODULE_7__, _moleculers__WEBPACK_IMPORTED_MODULE_10__, apis_payment__WEBPACK_IMPORTED_MODULE_13__, react_hook_form__WEBPACK_IMPORTED_MODULE_15__, apis_review__WEBPACK_IMPORTED_MODULE_18__, _apis_course__WEBPACK_IMPORTED_MODULE_20__]);
([_atoms__WEBPACK_IMPORTED_MODULE_2__, _organisms__WEBPACK_IMPORTED_MODULE_7__, _moleculers__WEBPACK_IMPORTED_MODULE_10__, apis_payment__WEBPACK_IMPORTED_MODULE_13__, react_hook_form__WEBPACK_IMPORTED_MODULE_15__, apis_review__WEBPACK_IMPORTED_MODULE_18__, _apis_course__WEBPACK_IMPORTED_MODULE_20__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





















const Details = ({ imageURL , course , courseId  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const token = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useSelector)((state)=>state.user.token);
    const loading = (0,_atoms__WEBPACK_IMPORTED_MODULE_2__/* .useLoading */ .r$)();
    const toast = (0,_iscv_toast__WEBPACK_IMPORTED_MODULE_17__.useToast)();
    const { control , setValue , getValues  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_15__.useForm)({
        defaultValues: {
            isPaid: false,
            review: undefined,
            rating: {
                isRating: false,
                hoveredNumber: 0
            },
            suggestions: []
        }
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!courseId) return;
        if (!token) return;
        (async ()=>{
            loading.open();
            await (0,apis_payment__WEBPACK_IMPORTED_MODULE_13__/* .checkPayment */ .JV)(courseId).then((success)=>setValue("isPaid", success.data.is_paid)).catch((error)=>console.log(error));
            loading.close();
        })();
    }, [
        courseId,
        token
    ]);
    const handleReview = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async ()=>{
        const rating = getValues("rating");
        if (!rating.courseReviewStar) {
            toast.warning("Vui l\xf2ng chọn số sao");
            return;
        }
        loading.open();
        if (!courseId) {
            toast.warning("Kh\xf4ng t\xecm thấy m\xe3 kh\xf3a học");
            return;
        }
        await (0,apis_review__WEBPACK_IMPORTED_MODULE_18__/* .postReview */ .Z)({
            courseId: courseId,
            courseReviewStar: rating.courseReviewStar,
            content: rating.content
        }).then(()=>{
            toast.success("Đ\xe1nh gi\xe1 th\xe0nh c\xf4ng");
            setValue("rating.isRating", false);
        }).catch((error)=>{
            console.log(error);
            toast.error("Đ\xe1nh gi\xe1 thất bại");
        });
        (async ()=>{
            loading.open();
            await (0,apis_payment__WEBPACK_IMPORTED_MODULE_13__/* .checkPayment */ .JV)(courseId).then((success)=>setValue("isPaid", success.data.is_paid)).catch((error)=>console.log(error));
            loading.close();
        })();
    }, [
        courseId,
        token
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!courseId) return;
        (async ()=>{
            loading.open();
            await (0,apis_review__WEBPACK_IMPORTED_MODULE_18__/* .getCourseReview */ .v)(courseId).then((success)=>setValue("review", success.data)).catch((error)=>console.log(error));
            loading.close();
        })();
    }, [
        courseId
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!courseId) return;
        (async ()=>{
            loading.open();
            await (0,_apis_course__WEBPACK_IMPORTED_MODULE_20__/* .getCoursesOfMaintype */ .to)(courseId).then((success)=>setValue("suggestions", success.data.map((x)=>x._id))).catch((error)=>console.log(error));
            loading.close();
        })();
    }, [
        courseId
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
        className: "bg-white",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_15__.Controller, {
                control: control,
                name: "rating.isRating",
                render: ({ field: { value: isRating  }  })=>{
                    if (!isRating) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "fixed z-[1000] inset-0",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "fixed bg-gray-400 opacity-50 inset-0 z-[1002]",
                                onClick: ()=>setValue("rating.isRating", false)
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: " transform-gpu fixed z-[1003] top-[40%] -translate-y-1/2 left-1/2 -translate-x-1/2 bg-white rounded-2xl w-[22rem] min-h-[20rem] flex flex-col gap-3 px-8 py-6",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col gap-2 mb-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "font-medium text-sm text-gray-900",
                                                children: "Bạn đ\xe1nh gi\xe1 kho\xe1 học n\xe0y thế n\xe0o?"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_15__.Controller, {
                                                control: control,
                                                name: "rating.courseReviewStar",
                                                render: ({ field: { value: courseReviewStar , onChange: onCourseReviewStarChange  }  })=>{
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "flex items-center justify-between gap-2",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_15__.Controller, {
                                                            control: control,
                                                            name: "rating.hoveredNumber",
                                                            render: ({ field: { value: hoveredNumber , onChange  }  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        1,
                                                                        2,
                                                                        3,
                                                                        4,
                                                                        5
                                                                    ].map((star, index)=>{
                                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_detail__WEBPACK_IMPORTED_MODULE_16__/* .StartIcon */ .Z, {
                                                                            className: clsx__WEBPACK_IMPORTED_MODULE_9___default()({
                                                                                "!fill-orange-400": hoveredNumber === 0 ? star <= (courseReviewStar || 0) : star <= hoveredNumber
                                                                            }, "fill-gray-300 cursor-pointer h-10"),
                                                                            onClick: ()=>onCourseReviewStarChange(star),
                                                                            onMouseEnter: ()=>onChange(star),
                                                                            onMouseLeave: ()=>onChange(0)
                                                                        }, star);
                                                                    })
                                                                })
                                                        })
                                                    });
                                                }
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_15__.Controller, {
                                        control: control,
                                        name: "rating.content",
                                        render: ({ field: { value: content , onChange  }  })=>{
                                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .TextAreaField */ .N7, {
                                                title: "B\xecnh luận th\xeam",
                                                name: "rating_comment",
                                                className: "flex-1 w-full",
                                                value: content,
                                                onChange: onChange,
                                                rows: 8,
                                                inputClassName: "flex-1 w-full p-3 rounded-xl min-h-[7rem] border !border-gray-400 text-gray-500 text-sm font-extralight",
                                                placeholder: "Nhập nội dung..."
                                            });
                                        }
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex justify-between items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .zx, {
                                                onClick: ()=>setValue("rating.isRating", false),
                                                className: "border border-gray-500 !text-gray-500 flex-1 !bg-white text-xl font-normal flex justify-center items-end",
                                                children: "Huỷ"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .zx, {
                                                onClick: ()=>handleReview(),
                                                className: " !bg-blue-secondary text-white flex-1 text-xl font-normal justify-center items-end",
                                                children: "Đ\xe1nh gi\xe1"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    });
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "h-[70vh] w-full relative",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_organisms__WEBPACK_IMPORTED_MODULE_7__/* .ImageComponent */ .cu, {
                    urldb: imageURL
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-fit bg-white flex px-28 py-16",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex-[2] h-full px-28 flex flex-col gap-8",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-full h-fit max-h-screen bg-white overflow-hidden p-4 rounded-xl flex flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-black font-semibold text-2xl",
                                        children: course?.course_name
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col gap-2 flex-1 overflow-hidden",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "text-sm uppercase text-[#2F80ED]",
                                                        children: "2/5 COMPLETED"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "text-sm uppercase text-[#2F80ED]",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_8__.BsCalendarMinus, {
                                                            size: 18
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex gap-1",
                                                children: [
                                                    1,
                                                    2,
                                                    3,
                                                    4,
                                                    5
                                                ].map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: clsx__WEBPACK_IMPORTED_MODULE_9___default()("flex-1 h-1 bg-[#2F80ED]", {
                                                            "opacity-25": item > 2
                                                        })
                                                    }, item))
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex flex-col gap-4 flex-1 overflow-y-auto",
                                                children: course?.chapters.map((chapter, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "h-fit p-2 px-4 border rounded-xl",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                "data-te-collapse-init": true,
                                                                "data-te-ripple-init": true,
                                                                "data-te-ripple-color": "light",
                                                                "data-te-target": `#collapse${chapter._id}`,
                                                                "aria-expanded": "false",
                                                                "aria-controls": "collapse",
                                                                className: "flex flex-col gap-2 cursor-pointer",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "flex justify-between items-center",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                children: chapter.chapter_name
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                className: "chev ease-linear transition-all duration-100",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiChevronDown, {
                                                                                    size: 20
                                                                                })
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "flex items-center justify-between",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: "flex items-center gap-1 text-xs text-[#252641CC]",
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__.AiOutlineClockCircle, {
                                                                                        size: 14
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                        children: [
                                                                                            chapter.duration,
                                                                                            " Hour"
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: "flex items-center gap-1 text-xs text-[#252641CC]",
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_8__.BsBook, {
                                                                                        size: 14
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                        children: [
                                                                                            chapter?.lessons?.length,
                                                                                            " Lessons"
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "!visible hidden divide-y-2",
                                                                id: `collapse${chapter._id}`,
                                                                "data-te-collapse-item": true,
                                                                children: chapter?.lessons?.map((lesson)=>{
                                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                                        href: `/learning/${lesson._id}?course_id=${course._id}`,
                                                                        className: "p-2 py-4 flex items-center justify-between text-sm",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                children: lesson.lesson_name
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                children: lesson.duration
                                                                            })
                                                                        ]
                                                                    }, lesson._id);
                                                                })
                                                            })
                                                        ]
                                                    }, chapter._id))
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex justify-between",
                                children: [
                                    1,
                                    2,
                                    3,
                                    4
                                ].map((num)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .zx, {
                                        className: "font-semibold !bg-[#0000001A] !text-[#00000069]",
                                        children: "Overview"
                                    }, num))
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_15__.Controller, {
                                control: control,
                                name: "review",
                                render: ({ field: { value: review  }  })=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex-1 w-full bg-[#9DCCFF4D] rounded-2xl p-6 overflow-hidden gap-2 flex flex-col",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "h-40 flex gap-9",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "w-48 h-full bg-white rounded-2xl flex flex-col justify-center items-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                                                className: "font-bold text-[#00000080] text-2xl",
                                                                children: [
                                                                    review?.averange.toFixed(1),
                                                                    " out of 5"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "flex gap-1",
                                                                children: [
                                                                    ...Array(Number(review?.averange.toFixed() || 0)).keys()
                                                                ].map((num)=>{
                                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__.AiFillStar, {
                                                                        color: "orange"
                                                                    }, num);
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                                className: "font-normal text-[#00000080] text-xl",
                                                                children: "Top Raiting"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "flex-1 h-full bg-white rounded-2xl p-2 flex flex-col gap-2",
                                                        children: [
                                                            1,
                                                            2,
                                                            3,
                                                            4,
                                                            5
                                                        ].reverse().map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "flex items-center gap-2",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                        className: "text-[#00000080]",
                                                                        children: [
                                                                            item,
                                                                            " Stars"
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "bg-[#D9D9D9] flex-1 h-2 rounded-3xl relative overflow-hidden",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                            className: "bg-[#2F80ED] h-2 absolute left-0 top-0 rounded-3xl",
                                                                            style: {
                                                                                width: `${(()=>{
                                                                                    if (!review) return 0;
                                                                                    switch(item){
                                                                                        case 1:
                                                                                            return review.oneStar;
                                                                                        case 2:
                                                                                            return review.twoStar;
                                                                                        case 3:
                                                                                            return review.threeStar;
                                                                                        case 4:
                                                                                            return review.fourStar;
                                                                                        case 5:
                                                                                            return review.fiveStar;
                                                                                        default:
                                                                                            return 0;
                                                                                    }
                                                                                })()}%`
                                                                            }
                                                                        })
                                                                    })
                                                                ]
                                                            }, item))
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex flex-col flex-1 overflow-auto h-full p-4 gap-3",
                                                children: review?.list?.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex items-center",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "flex flex-col",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "flex items-center",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "flex-shrink-0",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                    className: "h-10 w-10 rounded-full",
                                                                                    src: "/avatar.png",
                                                                                    alt: "Avatar"
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: "ml-4",
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                                                        className: "text-base font-bold text-gray-900",
                                                                                        children: item.fullname
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                        className: "flex gap-1",
                                                                                        children: [
                                                                                            ...Array(item.course_review_star || 0).keys()
                                                                                        ].map((num)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__.AiFillStar, {
                                                                                                color: "orange"
                                                                                            }, num))
                                                                                    })
                                                                                ]
                                                                            })
                                                                        ]
                                                                    }),
                                                                    item.content && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        children: item.content
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "whitespace-nowrap flex justify-center items-center gap-1 opacity-75",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiClock, {
                                                                        color: "gray"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "text-xs",
                                                                        children: (0,_utils_date__WEBPACK_IMPORTED_MODULE_19__/* .calculateRelativeTime */ .i)(new Date(item.createdAt), new Date())
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }))
                                            })
                                        ]
                                    });
                                }
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex-1 bg-white shadow-md rounded-lg h-fit p-6 flex flex-col gap-4 -translate-y-[280px]",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "h-[180px]",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .ImageOptimizing */ .UP, {
                                    blurhash: "NVKKc$Ny4n%LNG%M~qxux]o2o2X8-;kW%LoeRjt7",
                                    className: " rounded-xl",
                                    src: `${"https://node.edupath.ftisu.vn/"}${course?.course_img}`
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-4 items-center pt-2",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: "text-2xl font-bold text-black",
                                        children: [
                                            course?.course_fee?.toLocaleString(),
                                            " đ"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-base font-bold text-[#00000080]",
                                        children: "50% Off"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "text-[#2F80ED] text-sm font-bold text-center",
                                children: [
                                    course?.duration,
                                    " hour left at this price"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_15__.Controller, {
                                control: control,
                                name: "isPaid",
                                render: ({ field: { value: isPaid  }  })=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .zx, {
                                        className: clsx__WEBPACK_IMPORTED_MODULE_9___default()("w-full text-base font-bold h-10 text-center flex justify-center items-center", {
                                            "!bg-[#2F80ED]": !isPaid,
                                            "!bg-green-600": isPaid
                                        }),
                                        onClick: ()=>{
                                            if (isPaid) {
                                                setValue("rating.isRating", true);
                                                return;
                                            }
                                            router.push(`/payment?course_id=${course?._id}`);
                                        },
                                        children: [
                                            !isPaid && "Buy Now",
                                            isPaid && "Đ\xe1nh gi\xe1 ngay"
                                        ]
                                    });
                                }
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex gap-2",
                                        children: course?.tag_id && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "bg-blue-500 rounded-full h-fit w-fit px-4 text-xs py-[1px] text-white",
                                            children: course.tag_name
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-xl font-bold text-black",
                                        children: course?.course_name
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex gap-2 items-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_5__.FaCertificate, {
                                                size: 24,
                                                color: "#2F80ED"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-sm font-bold text-[#00000080]",
                                                children: "Money Back Guarantee"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex gap-2 items-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__.AiFillCamera, {
                                                size: 24,
                                                color: "#2F80ED"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-sm font-bold text-[#00000080]",
                                                children: "Access on all devices"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex gap-2 items-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__.HiDocumentText, {
                                                size: 24,
                                                color: "#2F80ED"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-sm font-bold text-[#00000080]",
                                                children: "Certification of completion"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex gap-2 items-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_5__.FaChartBar, {
                                                size: 20,
                                                color: "#2F80ED"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-sm font-bold text-[#00000080]",
                                                children: "32 Moduls"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "h-[1px] w-full bg-black"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-xl font-bold text-black",
                                        children: "Training 5 or more people"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-[#696984] text-sm",
                                        children: course?.description
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-xl font-bold text-black",
                                        children: "Share this course"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__.AiFillTwitterCircle, {
                                                size: 18
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__.AiFillGoogleCircle, {
                                                size: 18
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__.AiFillRedditCircle, {
                                                size: 18
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full min-h-[80vh] p-20 flex flex-col gap-2 bg-[#9DCCFF] mix-blend-normal bg-opacity-20",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "text-xl font-bold text-black",
                                children: "Marketing Articles"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_14___default()), {
                                className: "uppercase border-[1.5px] border-gray-400 btn !bg-white text-gray-500",
                                href: "/course",
                                children: "Xem tất cả"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-between flex-wrap gap-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_15__.Controller, {
                            control: control,
                            name: "suggestions",
                            render: ({ field: { value: suggestions  }  })=>{
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: suggestions.map((suggestion)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_moleculers__WEBPACK_IMPORTED_MODULE_10__/* .Course */ .T0, {
                                            courseId: suggestion
                                        }, suggestion);
                                    })
                                });
                            }
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "h-fit w-full p-10",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex p-12 gap-6 h-[60vh] items-center",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col gap-3 flex-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-3xl font-semibold text-gray-900",
                                        children: "Everything you can do in a physical classroom, you can do with TOTC"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-[#696984] text-base",
                                        children: "TOTC’s school management software helps traditional and online schools manage scheduling, attendance, payments and virtual classrooms all in one secure cloud-based system."
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "underline",
                                        children: "Learn more"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "h-full flex-1 rounded-lg overflow-hidden",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .ImageOptimizing */ .UP, {
                                    blurhash: "NVKKc$Ny4n%LNG%M~qxux]o2o2X8-;kW%LoeRjt7",
                                    src: "/banner_details.png"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col gap-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex items-center justify-start",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "text-xl font-bold text-black",
                                    children: "Top Education offers and deals are listed here"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex justify-between flex-wrap",
                                children: [
                                    1,
                                    2,
                                    3,
                                    4,
                                    5
                                ].map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "h-[260px] bg-white w-[260px]       rounded-lg flex flex-col gap-1 shadow-md relative p-4",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "h-full w-full rounded-lg overflow-hidden absolute top-0 left-0 z-1 opacity-80",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .ImageOptimizing */ .UP, {
                                                    blurhash: "NVKKc$Ny4n%LNG%M~qxux]o2o2X8-;kW%LoeRjt7",
                                                    src: "/banner_details.png"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "relative z-2 flex flex-col gap-4",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "relative z-2",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "w-12 h-12 rounded-xl flex items-center justify-center bg-red-500 text-white font-bold text-base text-center ",
                                                            children: "50%"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex flex-col gap-2 font-semibold",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                                children: "FOR INSTRUCTORS"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: "TOTC’s school management software helps traditional and online schools manage scheduling,"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }, item))
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Details);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4389:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var apis_learning__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3600);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6915);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(519);
/* harmony import */ var _assets_learning__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2899);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([apis_learning__WEBPACK_IMPORTED_MODULE_1__, _atoms__WEBPACK_IMPORTED_MODULE_9__]);
([apis_learning__WEBPACK_IMPORTED_MODULE_1__, _atoms__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const Elearning = ({ lessonId , course , courseId  })=>{
    const [video, setVideo] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    const loading = (0,_atoms__WEBPACK_IMPORTED_MODULE_9__/* .useLoading */ .r$)();
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        if (!lessonId) return;
        if (!courseId) return;
        (async ()=>{
            loading.open();
            await (0,apis_learning__WEBPACK_IMPORTED_MODULE_1__/* .getVideo */ .o)(lessonId, courseId).then((success)=>setVideo(success)).catch((error)=>console.log(error));
            loading.close();
        })();
    }, [
        lessonId,
        courseId
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bg-[#9DCCFF] p-8 flex justify-center  h-screen items-center w-full",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-full m-auto h-full flex items-center justify-between gap-4",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex-1 h-full flex flex-col gap-2 w-full",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex gap-2 h-24 justify-between items-center ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: `/course/${courseId}`,
                                    className: "w-9 h-9 bg-[#2F80ED] text-white flex items-center justify-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_8__.MdOutlineArrowBack, {
                                        size: 20
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "h-fit bg-white rounded-xl p-3 flex-1",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col overflow-hidden truncate",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-black font-semibold text-2xl truncate",
                                                children: course.course_name
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex items-center gap-4 text-xs",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                        children: [
                                                            course.lesson_quantity,
                                                            " Lesson"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                        children: [
                                                            course.duration,
                                                            " hours"
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "rounded-xl overflow-hidden w-full",
                            children: video && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_9__/* .Video */ .nk, {
                                video: video,
                                thumbnail: _assets_learning__WEBPACK_IMPORTED_MODULE_10__/* .thumbnail.src */ .Q.src
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-[21rem] h-full flex flex-col gap-8",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full h-fit max-h-screen bg-white overflow-hidden p-4 rounded-xl flex flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-black font-semibold text-xl whitespace-nowrap overflow-hidden text-ellipsis",
                                children: course.course_name
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col gap-2 flex-1 overflow-hidden",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center justify-between",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-sm uppercase text-[#2F80ED]",
                                                children: "2/5 COMPLETED"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-sm uppercase text-[#2F80ED]",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_6__.BsCalendarMinus, {
                                                    size: 18
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex gap-1",
                                        children: course.chapters.map((chapter, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("flex-1 h-1 bg-[#2F80ED]", {
                                                    "opacity-25": index > 2
                                                })
                                            }, chapter._id))
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex flex-col gap-4 flex-1 overflow-y-auto",
                                        children: course.chapters.map((chapter)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "h-fit p-2 px-4 border rounded-xl",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        "data-te-collapse-init": true,
                                                        "data-te-ripple-init": true,
                                                        "data-te-ripple-color": "light",
                                                        "data-te-target": `#collapse${chapter._id}`,
                                                        "aria-expanded": "false",
                                                        "aria-controls": "collapse",
                                                        className: "flex flex-col gap-2 cursor-pointer",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "flex justify-between items-center",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        children: chapter.chapter_name
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "chev ease-linear transition-all duration-100",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_7__.FiChevronDown, {
                                                                            size: 20
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "flex items-center justify-between",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "flex items-center gap-1 text-xs text-[#252641CC]",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__.AiOutlineClockCircle, {
                                                                                size: 14
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                children: [
                                                                                    chapter.duration,
                                                                                    " Hour"
                                                                                ]
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "flex items-center gap-1 text-xs text-[#252641CC]",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_6__.BsBook, {
                                                                                size: 14
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                children: [
                                                                                    chapter.lessons?.length,
                                                                                    " Lessons"
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "!visible hidden divide-y-2",
                                                        id: `collapse${chapter._id}`,
                                                        "data-te-collapse-item": true,
                                                        children: chapter.lessons?.map((lesson)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                                href: `/learning/${lesson._id}?course_id=${course._id}`,
                                                                className: "p-2 py-4 flex items-center justify-between text-sm gap-1",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        className: " text-ellipsis whitespace-nowrap overflow-hidden",
                                                                        children: lesson.lesson_name
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                        className: " whitespace-nowrap",
                                                                        children: [
                                                                            lesson.duration,
                                                                            "h"
                                                                        ]
                                                                    })
                                                                ]
                                                            }, lesson._id))
                                                    })
                                                ]
                                            }, chapter._id))
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Elearning);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2543:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(519);
/* harmony import */ var _organisms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2706);
/* harmony import */ var _assets_home_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6799);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6915);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _moleculers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5438);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _atoms__WEBPACK_IMPORTED_MODULE_3__, _organisms__WEBPACK_IMPORTED_MODULE_4__, _moleculers__WEBPACK_IMPORTED_MODULE_8__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _atoms__WEBPACK_IMPORTED_MODULE_3__, _organisms__WEBPACK_IMPORTED_MODULE_4__, _moleculers__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const Home = ({ courses , stateStore , user  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_organisms__WEBPACK_IMPORTED_MODULE_4__/* .ModalSurvey */ .oJ, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "h-[90vh] bg-[url('/banner_home.png')] bg-no-repeat bg-cover flex p-32 items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 flex pr-10",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-4/5 flex flex-col gap-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "uppercase text-4xl font-semibold",
                                    children: "EDUPATH TI\xcaN PHONG LỘ TR\xccNH HỌC IT"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-sm text-[#4F4F4F]",
                                    children: "Ch\xfang t\xf4i cung cấp lộ tr\xecnh học tập được c\xe1 nh\xe2n ho\xe1 theo khả năng của mỗi học vi\xean"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 w-full flex items-center justify-end",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "bg-white shadow-lg rounded-lg p-8 w-[400px] min-h-[230px] flex gap-[20px] flex-col justify-between relative",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex gap-8 items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_home_index__WEBPACK_IMPORTED_MODULE_5__/* .BotIcon */ .Z8, {
                                            className: "w-[95px] h-[95px] object-contain"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            className: "flex-1 leading-[30px] text-[22px] font-bold text-blue-secondary",
                                            children: "Xin ch\xe0o, m\xecnh l\xe0 Usagi"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-sm text-[#3C4043]",
                                    children: "M\xecnh c\xf3 thể hỗ trợ bạn t\xecm kiếm c\xe1c cơ hội việc l\xe0m, mức lương v\xe0 c\xf4ng ty tuyển dụng,..."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .zx, {
                                    className: "!bg-blue-500 uppercase h-12 !text-base",
                                    onClick: ()=>router.push("/chatbot"),
                                    children: "TR\xd2 CHUYỆN NGAY"
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "px-[10%] pb-48",
                children: [
                    user?.token && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "py-4",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex justify-between items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                            className: "text-xl font-medium",
                                            children: "D\xc0NH CHO BẠN"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                            href: "/course",
                                            className: "h-10 uppercase px-8 border-[1.5px] btn !border-[#0066FF] !text-[#0066FF] !bg-white",
                                            children: "Xem tất cả"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "grid grid-cols-3 grid-rows-2 gap-4 h-[90vh]",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        href: "/roadmap",
                                        className: "col-span-2 rounded-xl overflow-hidden p-6 bg-[url('/home_a.png')] bg-cover bg-no-repeat",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                    className: "uppercase font-medium",
                                                    children: "lộ tr\xecnh của bạn"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-sm text-[#4F4F4F]",
                                                    children: "Tiến độ 15%"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        href: "/mycourse",
                                        className: "row-span-2 col-start-3 rounded-xl overflow-hidden p-6 bg-[url('/home_b.png')] bg-cover bg-no-repeat",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                    className: "uppercase font-medium",
                                                    children: "kho\xe1 học của bạn"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-sm text-[#4F4F4F]",
                                                    children: "12 b\xe0i học"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "row-start-2  rounded-xl overflow-hidden p-6 bg-[url('/home_c.png')] bg-cover bg-no-repeat",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                    className: "uppercase font-medium",
                                                    children: "lộ tr\xecnh của bạn"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-sm text-[#4F4F4F]",
                                                    children: "Tiến độ 15%"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "row-start-2  rounded-xl overflow-hidden p-6 bg-[url('/home_d.png')] bg-cover bg-no-repeat",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                    className: "uppercase font-medium",
                                                    children: "lộ tr\xecnh của bạn"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-sm text-[#4F4F4F]",
                                                    children: "Tiến độ 15%"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "py-4",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex justify-between items-center overflow-auto",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                            className: "uppercase text-xl font-medium",
                                            children: "KH\xf3a học phổ biến"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                            href: "/course",
                                            className: "h-10 uppercase px-8 !border-[#0066FF] !text-[#0066FF] btn !bg-white",
                                            children: "Xem tất cả"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                                name: "activeCourse",
                                defaultValue: undefined,
                                control: stateStore.control,
                                render: ({ field: { value: activeCourse , onChange  }  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "h-[90vh] flex w-full rounded-lg overflow-hidden",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex-[1.5] flex flex-col h-full overflow-y-auto bg-gray-50 gap-1 p-2 ",
                                                children: courses.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_moleculers__WEBPACK_IMPORTED_MODULE_8__/* .OverviewCourse */ .TT, {
                                                        courseId: item,
                                                        onClick: ()=>onChange(item)
                                                    }, item))
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                                                control: stateStore.control,
                                                name: "activeCourse",
                                                render: ({ field: { value: courseId  }  })=>{
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_moleculers__WEBPACK_IMPORTED_MODULE_8__/* .ActiveCourse */ .SN, {
                                                        courseId: courseId || courses.at(0)
                                                    });
                                                }
                                            })
                                        ]
                                    })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mt-8",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "uppercase text-3xl text-center text-[#000054] pb-8",
                                        children: "Hơn 12.000 kh\xf3a học được t\xecm kiếm"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-2/3 m-auto",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_3__/* .TextFieldSearch */ .qJ, {
                                            className: "!bg-[#F8F8F8] h-12 text-black",
                                            placeholder: "Bạn muốn học g\xec?"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 259:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(519);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(178);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_fc__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6915);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_atoms__WEBPACK_IMPORTED_MODULE_2__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, framer_motion__WEBPACK_IMPORTED_MODULE_6__]);
([_atoms__WEBPACK_IMPORTED_MODULE_2__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, framer_motion__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const Login = ({ loginForm , handleSubmit  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bg-white h-screen w-full flex items-center px-5 py-8",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-2/3 flex items-center h-[90%] m-auto shadow-lg rounded-xl overflow-hidden",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-1 h-full",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .ImageOptimizing */ .UP, {
                        src: "/login.png"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-1 p-4 w-full h-full overflow-auto",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-2/3 m-auto flex flex-col h-full",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex justify-end items-end flex-col w-full",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "bg-[url('/logo_2.png')] bg-no-repeat h-10 w-28 bg-cover"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__.AnimatePresence, {
                                mode: "wait",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.div, {
                                    initial: {
                                        y: 10,
                                        opacity: 0
                                    },
                                    animate: {
                                        y: 0,
                                        opacity: 1
                                    },
                                    exit: {
                                        y: -10,
                                        opacity: 0
                                    },
                                    transition: {
                                        duration: 0.2
                                    },
                                    className: "flex-1 flex items-center flex-col gap-2 mt-6",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-sm font-medium",
                                            children: "Ch\xe0o mừng đến với EduPath"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "p-2 bg-[#2F80ED99] flex gap-4 w-full h-11 text-xs font-medium justify-between rounded-full",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "bg-[#2F80ED] text-white flex items-center justify-center px-4 w-1/2 text-center rounded-full cursor-pointer",
                                                    children: "Đăng nhập"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                    href: "/register",
                                                    className: "w-1/2 text-center text-white flex items-center justify-center cursor-pointer",
                                                    children: "Đăng k\xfd"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                            className: "flex flex-col gap-4",
                                            onSubmit: loginForm.handleSubmit(handleSubmit),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "mt-2 text-sm text-[#5B5B5B] w-full ",
                                                    children: '"Learning is a treasure that will follow its owner everywhere."'
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_4__.Controller, {
                                                    name: "username",
                                                    control: loginForm.control,
                                                    render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .TextField */ .nv, {
                                                            ...field,
                                                            errors: fieldState.error,
                                                            title: "T\xean đăng nhập",
                                                            required: true,
                                                            placeholder: "Nhập username"
                                                        })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_4__.Controller, {
                                                    name: "password",
                                                    control: loginForm.control,
                                                    render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .TextField */ .nv, {
                                                            ...field,
                                                            errors: fieldState.error,
                                                            type: "password",
                                                            title: "Mật khẩu",
                                                            required: true,
                                                            placeholder: "Nhập mật khẩu"
                                                        })
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex justify-between items-center mt-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "flex items-center",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    id: "default-checkbox",
                                                                    type: "checkbox",
                                                                    className: "w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 "
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    htmlFor: "default-checkbox",
                                                                    className: "ml-2 text-xs font-medium text-gray-900",
                                                                    children: "Ghi nhớ đăng nhập"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "text-xs font-medium text-gray-900",
                                                            children: "Qu\xean mật khẩu?"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .zx, {
                                                    type: "submit",
                                                    className: "!text-sm font-semibold !bg-[#2F80ED] h-10 flex items-center justify-center",
                                                    children: "Đăng nhập"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-center italic text-sm text-[#838383]",
                                                    children: "Hoặc"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_atoms__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .zx, {
                                                    className: "!text-sm font-medium gap-2 !bg-[#F6F6F6] h-10 flex items-center justify-center !text-[#2F80ED]",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fc__WEBPACK_IMPORTED_MODULE_3__.FcGoogle, {
                                                            size: 20
                                                        }),
                                                        " Đăng nhập với Google"
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Login);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7699:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_mycourse__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9874);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9030);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(519);
/* harmony import */ var _moleculers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5438);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_atoms__WEBPACK_IMPORTED_MODULE_4__, _moleculers__WEBPACK_IMPORTED_MODULE_5__]);
([_atoms__WEBPACK_IMPORTED_MODULE_4__, _moleculers__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const MyCourse = (props)=>{
    const { data  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "p-4 bg-white w-full flex flex-col items-center",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "p-4 rounded-2xl flex gap-8 max-h-[30rem] w-full justify-between",
                style: {
                    backgroundImage: `url(${_assets_mycourse__WEBPACK_IMPORTED_MODULE_1__/* .background.src */ .O.src})`
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                        src: _assets_mycourse__WEBPACK_IMPORTED_MODULE_1__/* .avatar.src */ .r.src,
                        width: 500,
                        height: 500,
                        alt: "avatar",
                        className: "rounded-full border-8 border-white w-[15rem] h-[15rem]"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: " rounded-2xl relative flex-1 overflow-hidden",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "absolute inset-0 bg-white opacity-80"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "absolute inset-0 p-8 flex flex-col w-full gap-4",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: " items-stretch flex gap-3 justify-between",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-2xl text-black",
                                                children: data?.user.fullname
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_4__/* .Button */ .zx, {
                                                className: "!bg-blue-secondary",
                                                children: "Edit Profile"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                        children: "Assistant Professor at Mcmaster University"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: " font-light",
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt utlabore et dolore magna aliqua. Ut enum ad minim veniam, quis nostrud"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex items-start gap-5",
                        children: data?.tags.map((tag)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_4__/* .Button */ .zx, {
                                className: "!bg-blue-secondary",
                                children: tag.tag_name
                            }, tag._id);
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex gap-7 flex-wrap",
                        children: data?.courses.map((course)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_moleculers__WEBPACK_IMPORTED_MODULE_5__/* .MyCourseItem */ .MO, {
                                course: course
                            }, course._id);
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyCourse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8471:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_payment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6918);
/* harmony import */ var apis_payment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8088);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9030);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6915);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(519);
/* harmony import */ var _moleculers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5438);
/* harmony import */ var _iscv_toast__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7608);
/* harmony import */ var _iscv_toast__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_iscv_toast__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([apis_payment__WEBPACK_IMPORTED_MODULE_2__, framer_motion__WEBPACK_IMPORTED_MODULE_4__, _atoms__WEBPACK_IMPORTED_MODULE_9__, _moleculers__WEBPACK_IMPORTED_MODULE_10__]);
([apis_payment__WEBPACK_IMPORTED_MODULE_2__, framer_motion__WEBPACK_IMPORTED_MODULE_4__, _atoms__WEBPACK_IMPORTED_MODULE_9__, _moleculers__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const Payment = (props)=>{
    const { query , push  } = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const courseId = query.course_id;
    const [similarCourses, setSimilarCourses] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)([]);
    const [course, setCourse] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(undefined);
    const loading = (0,_atoms__WEBPACK_IMPORTED_MODULE_9__/* .useLoading */ .r$)();
    const [isPaid, setIsPaid] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(true);
    const toast = (0,_iscv_toast__WEBPACK_IMPORTED_MODULE_11__.useToast)();
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (!courseId) return;
        (0,apis_payment__WEBPACK_IMPORTED_MODULE_2__/* .getCoursesSimilar */ .oB)(courseId).then((success)=>setSimilarCourses(success.data)).catch((error)=>console.log(error));
    }, [
        courseId
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (!courseId) return;
        (0,apis_payment__WEBPACK_IMPORTED_MODULE_2__/* .getCoursePrice */ .b6)(courseId).then((success)=>setCourse(success.data)).catch((error)=>console.log(error));
    }, [
        courseId
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (!courseId) return;
        (async ()=>{
            loading.open();
            (0,apis_payment__WEBPACK_IMPORTED_MODULE_2__/* .checkPayment */ .JV)(courseId).then((success)=>setIsPaid(success.data.is_paid)).catch((error)=>console.log(error));
            loading.close();
        })();
    }, [
        courseId
    ]);
    const handlePayment = async ()=>{
        if (isPaid) return;
        loading.open();
        await (0,apis_payment__WEBPACK_IMPORTED_MODULE_2__/* .makePayment */ .DP)(courseId).then(()=>{
            toast.success("Thanh to\xe1n th\xe0nh c\xf4ng");
            push(`/course/${courseId}`);
        }).catch((error)=>{
            console.log(error);
            toast.error("Thanh to\xe1n thất bại");
        });
        loading.close();
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "px-12 py-8 w-full flex flex-col gap-10",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex w-full h-[80vh] gap-12",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex-1 aspect-square shadow-xl bg-white flex flex-col justify-between  items-center p-5 gap-4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                alt: "payment",
                                src: _assets_payment__WEBPACK_IMPORTED_MODULE_1__/* .payment.src */ .m.src,
                                width: 500,
                                height: 500,
                                className: "rounded-2xl h-3/4 object-contain"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: " font-extralight text-gray-400 text-sm",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                className: " text-gray-500 text-sm font-semibold",
                                                children: "Lưu \xfd:"
                                            }),
                                            ' Nếu bạn kh\xf4ng nhận được phản hồi trong v\xf2ng 5 ph\xfat sau khi bấm “Đ\xe3 thanh to\xe1n", vui l\xf2ng li\xean hệ hotline',
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                href: "tel:+84877771703",
                                                className: "text-blue-secondary",
                                                children: "0877771703"
                                            }),
                                            " ",
                                            "để được hỗ trợ"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_9__/* .Button */ .zx, {
                                        className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("text-white h-[40px] !rounded-lg w-full text-center flex justify-center items-center", {
                                            "!bg-blue-secondary": !isPaid
                                        }, {
                                            "btn-disabled": isPaid
                                        }),
                                        onClick: handlePayment,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text-lg font-light",
                                            children: "Đ\xe3 thanh to\xe1n"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 h-fit flex",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-4/5 mr-auto bg-[#EBF5FF] rounded-2xl flex flex-col p-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "w-full font-normal text-xl",
                                    children: "Đang chờ thanh to\xe1n"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "w-full text-center  text-2xl font-semibold py-5",
                                    children: !isPaid && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_moleculers__WEBPACK_IMPORTED_MODULE_10__/* .PaymentTimer */ .uB, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "text-sm text-gray-500 font-extralight border-b-[1.5px] border-gray-400 py-3",
                                    children: "*Sau khi hết thời gian đếm ngược, đơn h\xe0ng của bạn sẽ hết hiệu lực"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full flex items-center py-5 gap-7 border-b-[1.5px] border-gray-400",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            alt: "course",
                                            src: _assets_payment__WEBPACK_IMPORTED_MODULE_1__/* .courseImage.src */ .D.src,
                                            className: "w-[180px] h-[120px] rounded-[30px]",
                                            width: 200,
                                            height: 100
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex flex-col gap-5 flex-1",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "py-5",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                        className: "font-light",
                                                        children: course?.course_name
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        className: "text-sm font-light text-[#5B5B5B]",
                                                        children: [
                                                            course?.lesson_quantity,
                                                            " b\xe0i học"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                        className: "font-normal text-xl",
                                                        children: [
                                                            course?.course_fee?.toLocaleString(),
                                                            "đ"
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex w-full border-b-[1.5px] border-gray-400 justify-between py-5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                            className: "text-gray-400",
                                            children: "Tạm t\xednh"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "text-gray-400",
                                            children: [
                                                course?.course_fee?.toLocaleString(),
                                                " đ"
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex w-full border-b-[1.5px] border-gray-400 justify-between py-5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                            className: "text-gray-400",
                                            children: "Khuyến m\xe3i"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            className: "text-gray-400 font-extralight",
                                            children: "kh\xf4ng"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex w-full justify-between py-5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                            className: "text-black",
                                            children: "Tổng tiền"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "text-black",
                                            children: [
                                                course?.course_fee?.toLocaleString(),
                                                " đ"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full flex justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-xl font-light",
                                children: "Gợi \xfd cho bạn"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                href: "/course",
                                className: "border-[1.5px] border-blue-secondary bg-white text-blue-secondary py-3 px-7 rounded-xl",
                                children: "Xem tất cả"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "my-4 overflow-x-auto",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.AnimatePresence, {
                            mode: "wait",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                                className: "flex-1 h-full py-8 px-12 border-2 border-t-transparent rounded-b-lg",
                                initial: {
                                    y: 10,
                                    opacity: 0
                                },
                                animate: {
                                    y: 0,
                                    opacity: 1
                                },
                                exit: {
                                    y: -10,
                                    opacity: 0
                                },
                                transition: {
                                    duration: 0.2
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex justify-between overflow-x-auto w-full gap-4 py-5",
                                    children: similarCourses.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                                            initial: {
                                                opacity: 0,
                                                scale: 0.5
                                            },
                                            animate: {
                                                opacity: 1,
                                                scale: 1
                                            },
                                            transition: {
                                                duration: 0.8,
                                                delay: 0.1 * index,
                                                ease: [
                                                    0,
                                                    0.71,
                                                    0.2,
                                                    1.01
                                                ]
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_moleculers__WEBPACK_IMPORTED_MODULE_10__/* .Course */ .T0, {
                                                fitWidth: true,
                                                courseId: item._id
                                            }, item._id)
                                        }, item._id))
                                })
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Payment);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8105:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(519);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6915);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _iscv_toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7608);
/* harmony import */ var _iscv_toast__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_iscv_toast__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_atoms__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, framer_motion__WEBPACK_IMPORTED_MODULE_3__]);
([_atoms__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, framer_motion__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const Register = ({ registerForm , handleSubmit  })=>{
    const toast = (0,_iscv_toast__WEBPACK_IMPORTED_MODULE_6__.useToast)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "bg-white h-screen w-full flex items-center",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "d-flex justify-content-end"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-[80%] flex items-center h-[100%] m-auto shadow-lg rounded-xl overflow-hidden",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: " h-full",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_1__/* .ImageOptimizing */ .UP, {
                            src: "/register.png"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 p-4 w-full h-full overflow-auto",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-2/3 m-auto flex flex-col",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex justify-end items-end flex-col w-full",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "bg-[url('/logo_2.png')] bg-no-repeat h-10 w-28 bg-cover"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.AnimatePresence, {
                                    mode: "wait",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                                        initial: {
                                            y: 10,
                                            opacity: 0
                                        },
                                        animate: {
                                            y: 0,
                                            opacity: 1
                                        },
                                        exit: {
                                            y: -10,
                                            opacity: 0
                                        },
                                        transition: {
                                            duration: 0.2
                                        },
                                        className: "flex-1 flex items-center flex-col gap-2 mt-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-sm font-medium",
                                                children: "Ch\xe0o mừng đến với EduPath"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "p-2 bg-[#2F80ED99] flex gap-4 w-2/3 h-11 text-xs font-medium justify-between rounded-full",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                        href: "/login",
                                                        className: "w-1/2 text-center text-white flex items-center justify-center cursor-pointer",
                                                        children: "Đăng nhập"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "bg-[#2F80ED] text-white flex items-center justify-center px-4 w-1/2 text-center rounded-full cursor-pointer",
                                                        children: "Đăng k\xfd"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                                className: "flex w-full flex-col gap-4",
                                                onSubmit: registerForm.handleSubmit(handleSubmit),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                                                        name: "email",
                                                        control: registerForm.control,
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_1__/* .TextField */ .nv, {
                                                                ...field,
                                                                errors: fieldState.error,
                                                                required: true,
                                                                title: "Địa chỉ Email",
                                                                placeholder: "Nhập username"
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                                                        name: "fullname",
                                                        control: registerForm.control,
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_1__/* .TextField */ .nv, {
                                                                ...field,
                                                                errors: fieldState.error,
                                                                required: true,
                                                                title: "Họ v\xe0 t\xean",
                                                                placeholder: "Nhập Họ v\xe0 t\xean"
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                                                        name: "username",
                                                        control: registerForm.control,
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_1__/* .TextField */ .nv, {
                                                                ...field,
                                                                errors: fieldState.error,
                                                                required: true,
                                                                title: "T\xean đăng nhập",
                                                                placeholder: "Nhập username"
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                                                        name: "password",
                                                        control: registerForm.control,
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_1__/* .TextField */ .nv, {
                                                                ...field,
                                                                errors: fieldState.error,
                                                                required: true,
                                                                type: "password",
                                                                title: "Mật khẩu",
                                                                placeholder: "Nhập mật khẩu"
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                                                        name: "confirmPassword",
                                                        control: registerForm.control,
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_1__/* .TextField */ .nv, {
                                                                ...field,
                                                                errors: fieldState.error,
                                                                required: true,
                                                                type: "password",
                                                                title: "X\xe1c nhận lại mật khẩu",
                                                                placeholder: "Nhập lại mật khẩu"
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_1__/* .Button */ .zx, {
                                                        type: "submit",
                                                        className: "!text-sm font-semibold !bg-[#2F80ED] h-10 flex items-center justify-center mt-2",
                                                        children: "Đăng k\xfd"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Register);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5828:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var _atoms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(519);
/* harmony import */ var _moleculers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5438);
/* harmony import */ var _organisms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2706);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _atoms__WEBPACK_IMPORTED_MODULE_3__, _moleculers__WEBPACK_IMPORTED_MODULE_4__, _organisms__WEBPACK_IMPORTED_MODULE_5__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _atoms__WEBPACK_IMPORTED_MODULE_3__, _moleculers__WEBPACK_IMPORTED_MODULE_4__, _organisms__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const RoadMap = ({ roadmap , stateStore  })=>{
    const circumference = 60 * 2 * Math.PI;
    const percent = roadmap?.percent || 0;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "bg-white",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                name: "isOpenModal",
                control: stateStore.control,
                render: ({ field: { value , onChange  }  })=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: value && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_organisms__WEBPACK_IMPORTED_MODULE_5__/* .ModalRoadMap */ .Xz, {
                            onClose: ()=>onChange(false),
                            detailId: value
                        })
                    });
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-[url('/bg_skill.png')] h-screen w-full right-0 bg-no-repeat absolute z-10 top-0 bg-right-top blur-lg"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-[url('/bg_skill_2.png')] h-screen w-full right-0 bg-no-repeat absolute z-10 top-0 bg-left-top blur-lg"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "h-[50vh] w-2/3 m-auto p-14 flex gap-10",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-1 flex-col gap-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                children: "Ch\xe0o mừng quay lại với lộ tr\xecnh trở th\xe0nh"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "font-bold text-3xl text-[#5F6368]",
                                children: roadmap?.maintype_name
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex-1 flex flex-col relative",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "text-[#0066FF] font-bold text-lg ml-10",
                                children: "Tiến độ ho\xe0n th\xe0nh"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-[200px] overflow-hidden",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-[400px] h-[220px] absolute top-[20px] left-0",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms__WEBPACK_IMPORTED_MODULE_3__/* .ProgressLayout */ .Qt, {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "absolute top-[37px] left-[67px]",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                                className: "w-[162px] h-[162px]",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                        className: "text-white",
                                                        strokeWidth: 30,
                                                        stroke: "currentColor",
                                                        fill: "transparent",
                                                        r: 60,
                                                        cx: 80,
                                                        cy: 80
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                        className: "text-blue-500",
                                                        strokeWidth: 30,
                                                        strokeDasharray: percent !== 100 ? circumference - 30 : circumference,
                                                        strokeDashoffset: circumference - percent / 100 * circumference,
                                                        strokeLinecap: "round",
                                                        stroke: "currentColor",
                                                        fill: "transparent",
                                                        r: 60,
                                                        cx: 80,
                                                        cy: 80
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: "absolute text-lg text-gray-500 font-bold top-[108px] left-[126px]",
                                            children: [
                                                percent,
                                                "%"
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-4/5 m-auto relative mt-28 grid grid-cols-2 pb-20 z-20",
                children: roadmap?.sections.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_moleculers__WEBPACK_IMPORTED_MODULE_4__/* .MapItem */ .jC, {
                        onTap: (detailId)=>lodash__WEBPACK_IMPORTED_MODULE_6___default().throttle(()=>stateStore.setValue("isOpenModal", detailId), 1000)(),
                        numStep: index + 1,
                        details: item.details,
                        section_name: item.section_name,
                        odd: (index + 1) % 2 == 0
                    }, item.section_id))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RoadMap);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9886:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F6": () => (/* reexport safe */ _Payment__WEBPACK_IMPORTED_MODULE_7__.Z),
/* harmony export */   "J7": () => (/* reexport safe */ _AllCourses__WEBPACK_IMPORTED_MODULE_9__.Z),
/* harmony export */   "PO": () => (/* reexport safe */ _Details__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "SK": () => (/* reexport safe */ _Home__WEBPACK_IMPORTED_MODULE_5__.Z),
/* harmony export */   "aX": () => (/* reexport safe */ _Register__WEBPACK_IMPORTED_MODULE_4__.Z),
/* harmony export */   "ar": () => (/* reexport safe */ _RoadMap__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "bI": () => (/* reexport safe */ _Chatbot__WEBPACK_IMPORTED_MODULE_6__.Z),
/* harmony export */   "fG": () => (/* reexport safe */ _MyCourse__WEBPACK_IMPORTED_MODULE_8__.Z),
/* harmony export */   "m3": () => (/* reexport safe */ _Login__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "pq": () => (/* reexport safe */ _Elearning__WEBPACK_IMPORTED_MODULE_2__.Z)
/* harmony export */ });
/* harmony import */ var _Details__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6670);
/* harmony import */ var _RoadMap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5828);
/* harmony import */ var _Elearning__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4389);
/* harmony import */ var _Login__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(259);
/* harmony import */ var _Register__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8105);
/* harmony import */ var _Home__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2543);
/* harmony import */ var _Chatbot__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6509);
/* harmony import */ var _Payment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8471);
/* harmony import */ var _MyCourse__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7699);
/* harmony import */ var _AllCourses__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8723);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Details__WEBPACK_IMPORTED_MODULE_0__, _RoadMap__WEBPACK_IMPORTED_MODULE_1__, _Elearning__WEBPACK_IMPORTED_MODULE_2__, _Login__WEBPACK_IMPORTED_MODULE_3__, _Register__WEBPACK_IMPORTED_MODULE_4__, _Home__WEBPACK_IMPORTED_MODULE_5__, _Chatbot__WEBPACK_IMPORTED_MODULE_6__, _Payment__WEBPACK_IMPORTED_MODULE_7__, _MyCourse__WEBPACK_IMPORTED_MODULE_8__, _AllCourses__WEBPACK_IMPORTED_MODULE_9__]);
([_Details__WEBPACK_IMPORTED_MODULE_0__, _RoadMap__WEBPACK_IMPORTED_MODULE_1__, _Elearning__WEBPACK_IMPORTED_MODULE_2__, _Login__WEBPACK_IMPORTED_MODULE_3__, _Register__WEBPACK_IMPORTED_MODULE_4__, _Home__WEBPACK_IMPORTED_MODULE_5__, _Chatbot__WEBPACK_IMPORTED_MODULE_6__, _Payment__WEBPACK_IMPORTED_MODULE_7__, _MyCourse__WEBPACK_IMPORTED_MODULE_8__, _AllCourses__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5171:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ EChatbotFrom)
/* harmony export */ });
var EChatbotFrom;
(function(EChatbotFrom) {
    EChatbotFrom[EChatbotFrom["NONE"] = 0] = "NONE";
    EChatbotFrom[EChatbotFrom["STUDENT"] = 1] = "STUDENT";
    EChatbotFrom[EChatbotFrom["BOT"] = 2] = "BOT";
})(EChatbotFrom || (EChatbotFrom = {}));


/***/ }),

/***/ 5933:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "aU": () => (/* binding */ ELevel)
/* harmony export */ });
/* unused harmony exports ELanguage, EApprovalsStatus, ECourseStatus */
var ELevel;
(function(ELevel) {
    ELevel[ELevel["NONE"] = 0] = "NONE";
    ELevel[ELevel["ALL_LEVELS"] = 1] = "ALL_LEVELS";
    ELevel[ELevel["BEGINNER"] = 2] = "BEGINNER";
    ELevel[ELevel["INTERMEDIATE"] = 3] = "INTERMEDIATE";
    ELevel[ELevel["EXPERT"] = 4] = "EXPERT";
})(ELevel || (ELevel = {}));
var ELanguage;
(function(ELanguage) {
    ELanguage[ELanguage["NONE"] = 0] = "NONE";
    ELanguage[ELanguage["VIETNAMESE"] = 1] = "VIETNAMESE";
    ELanguage[ELanguage["ENGLISH"] = 2] = "ENGLISH";
})(ELanguage || (ELanguage = {}));
var EApprovalsStatus;
(function(EApprovalsStatus) {
    EApprovalsStatus[EApprovalsStatus["NONE"] = 0] = "NONE";
    EApprovalsStatus[EApprovalsStatus["ACCEPT"] = 1] = "ACCEPT";
    EApprovalsStatus[EApprovalsStatus["DENY"] = 2] = "DENY";
    EApprovalsStatus[EApprovalsStatus["WATTING"] = 3] = "WATTING";
})(EApprovalsStatus || (EApprovalsStatus = {}));
var ECourseStatus;
(function(ECourseStatus) {
    ECourseStatus[ECourseStatus["NONE"] = 0] = "NONE";
    ECourseStatus[ECourseStatus["WATTING"] = 1] = "WATTING";
    ECourseStatus[ECourseStatus["OPEN"] = 2] = "OPEN";
    ECourseStatus[ECourseStatus["CLOSE"] = 3] = "CLOSE";
    ECourseStatus[ECourseStatus["FULL_ACCESS"] = 4] = "FULL_ACCESS";
})(ECourseStatus || (ECourseStatus = {}));


/***/ }),

/***/ 2785:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ ERecommendStatus)
/* harmony export */ });
/* unused harmony export ERole */
var ERole;
(function(ERole) {
    ERole[ERole["NONE"] = 0] = "NONE";
    ERole[ERole["ADMIN"] = 1] = "ADMIN";
    ERole[ERole["STUDENT"] = 2] = "STUDENT";
})(ERole || (ERole = {}));
var ERecommendStatus;
(function(ERecommendStatus) {
    ERecommendStatus[ERecommendStatus["NONE"] = 0] = "NONE";
    ERecommendStatus[ERecommendStatus["FIRST_TIME"] = 1] = "FIRST_TIME";
    ERecommendStatus[ERecommendStatus["CHOOSEN"] = 2] = "CHOOSEN";
    ERecommendStatus[ERecommendStatus["DONE"] = 3] = "DONE";
})(ERecommendStatus || (ERecommendStatus = {}));


/***/ }),

/***/ 3426:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* binding */ calculateRelativeTime)
/* harmony export */ });
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);

function calculateRelativeTime(startDate, endDate) {
    const duration = moment__WEBPACK_IMPORTED_MODULE_0___default().duration(endDate.getTime() - startDate.getTime());
    return duration.humanize();
}


/***/ }),

/***/ 6267:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ converDateTime)
/* harmony export */ });
const converDateTime = (date)=>{
    if (!date) {
        return "";
    }
    const formattedDate = new Date(date).toLocaleDateString("en-GB", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
    });
    return formattedDate;
};


/***/ }),

/***/ 2239:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ extractLastName),
/* harmony export */   "r": () => (/* binding */ searchSubstring)
/* harmony export */ });
function searchSubstring(array, substring) {
    const results = [];
    for (const str of array){
        if (str.includes(substring)) {
            results.push(str);
        }
    }
    return results;
}
function extractLastName(fullName) {
    const words = fullName.split(" ");
    const lastName = words[words.length - 1];
    return lastName;
}


/***/ })

};
;